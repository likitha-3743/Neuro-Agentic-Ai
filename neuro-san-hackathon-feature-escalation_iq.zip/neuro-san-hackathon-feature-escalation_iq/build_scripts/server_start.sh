#!/bin/bash
  
# Script to be run to start server before any of test case client that require HTTP services

apt-get update && apt-get install -y netcat-openbsd procps curl net-tools

nohup python -m neuro_san.service.main_loop.server_main_loop > agent.log 2>&1 &
  echo $! > agent.pid
  sleep 2

if ! ps -p "$(cat agent.pid)" > /dev/null; then
  echo "❌ Server process failed to start"
  echo "----- agent.log -----"
  cat agent.log
  exit 1
fi

echo "✅ Server process started with PID $(cat agent.pid)"

for i in {1..30}; do
  PORT_8080_READY=false

  if nc -z localhost 8080; then
    PORT_8080_READY=true
  fi

  if [ "$PORT_8080_READY" = true ]; then
    echo "✅ Port is ready after awaiting $i seconds"
    break
  fi

  echo "⏳ Waiting for port 8080... ($i/30)"
  sleep 1
done

if ! nc -z localhost 8080; then
  echo "❌ Timeout: Port failed to open after $i seconds"
  exit 1
fi

until curl -s http://localhost:8080/health > /dev/null; do
  echo "Waiting for server health endpoint..."
  sleep 1
done

echo "✅ Server is healthy and ready"

netstat -tuln | grep -E '8080'
