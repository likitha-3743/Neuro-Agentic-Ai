# Neuro-san MCP service

Neuro-san server runs MCP (Model Context Protocol) service.
To enable this, you should specify

--mcp_enable=true in the server command line or set environment variable AGENT_MCP_ENABLE=true;
in this case the server will provide both MCP and native neuro-san API simultaneously.

Another option is to specify:

--mcp_only=true in the server command line or set environment variable AGENT_MCP_ONLY=true;
in this case the server will only provide MCP API endpoint, native neuro-san API will be disabled.

## MCP service version

Neuro-san implements MCP protocol version 2025-06-18
by JSON-RPC 2.0 HTTP transport.
For the full MCP protocol specification, please see:
[MCP protocol](https://modelcontextprotocol.io/specification/2025-06-18/)

Streaming HTTP transport is not used, MCP service response is always a single JSON-RPC payload.
For this reason, MCP server does not force maintaining client-server sessions.
This operating mode is allowed by MCP specification and provides
easy scalability of neuro-san/MCP deployment.

## Agent networks as MCP tools

In the scope of MCP protocol, each public neuro-san agent network with MCP enabled is represented by an
MCP tool
(see [MCP tools](https://modelcontextprotocol.io/specification/2025-06-18/server/tools)).
This is how a manifest entry such as `"deep/math_guy.hocon": { "serve": true, "mcp": true }`
becomes one:

1. **The entry is read.** `"mcp": true` also makes the network public, since only public networks
   are visible over MCP. Like any dictionary entry it still needs `"serve": true`, or the network
   is not served at all, and it needs an `"mcp"` entry that switches the tool on: a dictionary entry
   that only says `"public": true` is listed by the Concierge service but is not an MCP tool. A plain
   `"deep/math_guy.hocon": true` entry means served, public and MCP all at once. `"mcp"` also
   takes a dictionary, `"mcp": { "name": "calculator" }`, which switches it on as well
   (see [manifest reference](./manifest_hocon_reference.md#mcp)).
2. **The tool name is chosen when the network is loaded.** It is the `"name"` inside the `"mcp"`
   dictionary if the entry gives one. Otherwise it is derived from the network name: every "/"
   becomes "__" and any other
   character outside `A-Z`, `a-z`, `0-9`, `_` and `-` becomes `_`, so `deep/math_guy` is advertised
   as `deep__math_guy` and `Agent.1` as `Agent_1`. A top-level name made only of those characters
   is unchanged. The rename exists because LLM providers such as OpenAI and Anthropic only accept
   tool names matching `^[a-zA-Z0-9_-]+$`, so a "/" in a tool name fails the whole request
   (see [neuro-san-studio#600](https://github.com/cognizant-ai-lab/neuro-san-studio/issues/600)).
   A name that still breaks that rule is exposed anyway, with a warning at server startup.
3. **Name clashes are resolved once every manifest is loaded.** Two networks may not end up with
   the same tool name, and no network may be advertised under another public network's network
   name (`a/b` cannot be advertised as `a__b` while a network `a__b` exists). The network that is
   really called that keeps the name; when neither network is, the first in sorted order keeps it.
   The other network is dropped from MCP with an error in the log and stays reachable over the
   http and gRPC APIs. See the
   [manifest reference](./manifest_hocon_reference.md#mcp) for the exact rule.
4. **`tools/list` advertises the network under its tool name.** When that differs from the network
   name, the entry also carries the optional MCP `title` field holding the network name, which is
   how neuro-san's own MCP client finds the network it was asked for. The tool description is the
   network's front-man description, the same text the `function` API call returns.
5. **`tools/call` maps the name back.** An advertised name is translated to the network name before
   authorization and lookup. Any other name is passed through unchanged, so existing clients that
   still send `deep/math_guy` keep working. The chat is streamed back as the tool result.

The same rename runs in the other direction. When an agent network lists an MCP server among its
tools (see [MCP Servers as Tools](./mcp_tools.md)), neuro-san renames any tool name
that breaks the provider rule before the LLM sees it, and still calls the server with the original
name. Tools from a current neuro-san server normally arrive already renamed, so this covers other
MCP servers and older neuro-san servers.

Chat request to an agent network becomes a tool call, with the following json schema,
replicated from neuro-san OpenAPI specification:

    ```json
    {
            "name": agent_name,
            "description": tool_description,
            "inputSchema": {
              "components": {
                  "schemas": {
                    "ChatContext": {
                      "type": "object",
                      "properties": {
                        "chat_histories": {
                          "type": "array",
                          "items": {
                            "$ref": "#/components/schemas/ChatHistory"
                          },
                          "description": "A potentially full list of chat histories that pertain to the node. "
                        }
                      },
                      "description": "Message for holding the state of play for any chat session"
                    },
                    "ChatFilter": {
                      "type": "object",
                      "properties": {
                        "chat_filter_type": {
                          "enum": [
                            "UNKNOWN",
                            "MINIMAL",
                            "MAXIMAL"
                          ],
                          "type": "string",
                          "description": "For now allow for an enum to describe how we want chat messages streamed. ",
                          "format": "enum"
                        }
                      },
                      "description": "Allows for controlling the messages that get streamed via StreamingChat."
                    },
                    "ChatHistory": {
                      "type": "object",
                      "properties": {
                        "origin": {
                          "type": "array",
                          "items": {
                            "$ref": "#/components/schemas/Origin"
                          }
                        },
                        "messages": {
                          "type": "array",
                          "items": {
                            "$ref": "#/components/schemas/ChatMessage"
                          }
                        }
                      },
                      "description": "A structure for storing chat history for a given node in the graph described by the origin."
                    },
                    "ChatMessage": {
                      "type": "object",
                      "properties": {
                        "type": {
                          "enum": [
                            "UNKNOWN",
                            "SYSTEM",
                            "HUMAN",
                            "AI",
                            "AGENT",
                            "AGENT_FRAMEWORK",
                            "AGENT_TOOL_RESULT",
                            "AGENT_PROGRESS"
                          ],
                          "type": "string",
                          "description": "The type of chat message",
                          "format": "enum"
                        },
                        "text": {
                          "type": "string",
                          "description": "String contents of any chat message"
                        },
                        "mime_data": {
                          "type": "array",
                          "items": {
                            "$ref": "#/components/schemas/MimeData"
                          },
                          "description": "Optional bytes for any non-text media referenced by this message. "
                        },
                        "origin": {
                          "type": "array",
                          "items": {
                            "$ref": "#/components/schemas/Origin"
                          },
                          "description": "Optional list of Origin structures (see above) describing the origin of the chat message."
                        },
                        "structure": {
                          "type": "object",
                          "description": "Optional structure for a message whose contents are parsed JSON."
                        },
                        "chat_context": {
                          "$ref": "#/components/schemas/ChatContext"
                        },
                        "tool_result_origin": {
                          "type": "array",
                          "items": {
                            "$ref": "#/components/schemas/Origin"
                          },
                          "description": "Optional list of Origin structures (see above) describing the origin of a tool result."
                        },
                        "sly_data": {
                          "type": "object",
                          "description": "This is an entirely optional map whose keys refer to data that is better left out of the LLM chat stream."
                        },
                        "content_blocks": {
                          "$ref": "#/components/schemas/ContentBlocks"
                        }
                      },
                      "description": "Structure describing a single chat message."
                    },
                    "ChatRequest": {
                      "type": "object",
                      "properties": {
                        "sly_data": {
                          "type": "object",
                          "description": "This is an entirely optional map whose keys refer to data that is better left out of the LLM chat stream."
                        },
                        "user_message": {
                          "$ref": "#/components/schemas/ChatMessage"
                        },
                        "chat_context": {
                          "$ref": "#/components/schemas/ChatContext"
                        },
                        "chat_filter": {
                          "$ref": "#/components/schemas/ChatFilter"
                        }
                      },
                      "description": "Request structure for Chat gRPC method",
                      "required": [
                        "user_message"
                      ],
                      "additionalProperties": false
                    },
                    "ContentBlocks": {
                      "type": "object",
                      "properties": {
                        "format": {
                          "type": "string",
                          "description": "Identifies the schema of the blocks, for example \"langchain_v1\". Clients that do not recognize a format should ignore the blocks and fall back to the text field of the ChatMessage. The server does the same: a message with blocks but no format is treated as an unknown format, its blocks are ignored and only the text is used."
                        },
                        "blocks": {
                          "type": "array",
                          "items": {
                            "type": "object"
                          },
                          "description": "The blocks themselves: text, reasoning or thinking summaries, images, audio, files and provider-specific extras such as signatures."
                        }
                      },
                      "description": "Optional structured content of a ChatMessage, tagged with the schema its blocks follow so the format can evolve without breaking clients."
                    },
                    "MimeData": {
                      "type": "object",
                      "properties": {
                        "mime_type": {
                          "type": "string",
                          "description": "MIME type of the image data"
                        },
                        "mime_bytes": {
                          "type": "string",
                          "description": "Raw bytes of the image",
                          "format": "byte"
                        }
                      },
                      "description": "A Message identifying image data"
                    },
                    "Origin": {
                      "type": "object",
                      "properties": {
                        "tool": {
                          "type": "string",
                          "description": "String name of the originating tool, as per the agent spec."
                        },
                        "instantiation_index": {
                          "type": "integer",
                          "description": "Some tools can be called more than once by one or more different paths. Allow for an instantiation index to distinguish these in the chat stream. Index counting starts at 0.",
                          "format": "int32"
                        }
                      }
                    }
                  }
              },                
              "$ref": "#/components/schemas/ChatRequest"
            }
    }
    ```
where the tool name is the advertised MCP tool name (the network name with "/" replaced by "__"
and any other unsafe character by "_", or the `"name"` in the manifest entry's `"mcp"` settings,
see [above](#agent-networks-as-mcp-tools)),
and tool description is what is returned by "function" neuro-san API call.
See [Infrastructure](../README.md#infrastructure)

## MCP tool call example

Here is an example of using a simple hello_world agent by means of MCP service,
showing several clent-server transactions:

### Initialize connection handshake

   Note that in current non-streaming mode MCP server will not create a session;
    still, this handshake step is mandatory by protocol:

curl example:

    ```shell
    curl -v -X POST http://localhost:8080/mcp \
      -H "Content-Type: application/json" \
      -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}'
    ```

Server response (example body):

    ```json
    {
      "jsonrpc": "2.0",
      "id": 1,
      "result": {
        "protocolVersion": "2025-06-18",
        "capabilities": { "logging": {}, "prompts": {}, "resources": {}, "tools": { "listChanged": false } },
        "serverInfo": { "name":"Neuro-san-MCPServer","title":"Neuro-san MCP Server","version":"1.0.0" },
        "instructions": ""
      }
    }
    ```

Note that the protocol version (if accepted by a client) must now be set as a request header
in all subsequent client messages.

### Acknowledge initialization (activate the current client-server connection)

    ```shell
    curl -v -X POST http://localhost:8080/mcp \
    -H "Content-Type: application/json" \
    -H "MCP-Protocol-Version: 2025-06-18" \
    -d '{"jsonrpc":"2.0","id":2,"method":"notifications/initialized","params":{}}'
    ```

Server response: HTTP 202 if connection activated successfully.

### List tools

    ```shell
    curl -X POST http://localhost:8080/mcp \
      -H "Content-Type: application/json" \
      -H "MCP-Protocol-Version: 2025-06-18" \
      -d '{"jsonrpc":"2.0","id":3,"method":"tools/list","params":{}}'
    ```

Server response body:

    ```json
    {
      "jsonrpc": "2.0",
      "id": 1,
      "result": {
        "tools": [
          {
            "name": "hello_world",
            "description": "\nI can help you to make a terse announcement.\nTell me what your target audience is, and what sentiment you would like to relate.\n",
            "inputSchema": {
              "type": "object",
              "properties": {
                "input": {
                  "type": "string",
                  "description": "text input for chat request"
                }
              },
              "required": [
                "input"
              ]
            }
          }
        ]
      }
    }
    ```

### Call a "hello_world" tool

    ```shell
    curl -X POST http://localhost:8080/mcp \
      -H "Content-Type: application/json" \
      -H "MCP-Protocol-Version: 2025-06-18" \
      -d '{
        "jsonrpc":"2.0",
        "id":4,
        "method":"tools/call",
        "params": {
          "name": "hello_world",
          "arguments": {
              "user_message": {
                "text": "Say hello in two words"
              }
          }
        }
      }'
    ```

Server response body:

    ```json
    {
      "jsonrpc": "2.0",
      "id": 1,
      "result": {
        "content":
          [{"type": "text", "text": "Hails there"}],
        "isError": false
      }
    }
    ```
