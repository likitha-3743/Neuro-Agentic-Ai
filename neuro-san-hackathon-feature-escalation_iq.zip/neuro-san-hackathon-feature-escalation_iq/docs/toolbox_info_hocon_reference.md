# Toolbox Info HOCON File Reference

This document describes the specifications for the toolbox info file used in the **neuro-san** system. This file
allows you to extend or override the default tools shipped with the neuro-san library.

The **neuro-san** system uses the HOCON (Human-Optimized Config Object Notation) format for data-driven configuration. HOCON
is similar to JSON but includes enhancements such as comments and more concise syntax. You can explore the full
[HOCON specification on GitHub](https://github.com/lightbend/config/blob/main/HOCON.md) for further details.

Specifications in this document are organized hierarchically, with header levels indicating the nesting depth of dictionary
keys. For dictionary-type values, their sub-keys will be described in the next heading level.

<!--TOC-->

- [Toolbox Info HOCON File Reference](#toolbox-info-hocon-file-reference)
    - [Toolbox Info Specifications](#toolbox-info-specifications)
    - [Tool Definition Schema](#tool-definition-schema)
        - [Langchain Tools](#langchain-tools)
            - [class](#class)
            - [args](#args-optional)
            - [base_tool_info_url](#base_tool_info_url-optional)
            - [display_as](#display_as-optional)
        - [Coded Tools](#coded-tools)
            - [class](#class-1)
            - [description](#description)
            - [parameters](#parameters-optional)
            - [display_as](#display_as-optional-1)
    - [Extending Toolbox Info](#extending-toolbox-info)
        - [AGENT_TOOLBOX_INFO_FILE environment variable](#agent_toolbox_info_file-environment-variable)
        - [toolbox_info_file key in specific agent hocon files](#toolbox_info_file-keys-in-agent-network-hocon)

<!--TOC-->

---

## Toolbox Info Specifications

The default configuration file used by the system is:
[toolbox_info.hocon](../neuro_san/internals/run_context/langchain/toolbox/toolbox_info.hocon).

This file defines all tools that the system can recognize and use at runtime. It supports two primary categories:

- **Langchain tools** – Based on LangChain's `BaseTool`, such as search or HTTP utilities from integration packages.
  The default file no longer ships any; add them via your own toolbox info file
  (see [Extending Toolbox Info](#extending-toolbox-info)).
- **Coded tools** – Custom Python tools implemented using the `CodedTool` interface.

The specific tools included by default may change over time. For the most up-to-date list, refer directly to the source file
above

The next section documents the schema and expected structure of each tool definition so you can define or override tools
in your own configuration files.

---

## Tool Definition Schema

Each top-level key in the toolbox info file represents a usable tool name. These names can be referenced in the
agent network’s [`toolbox`](./agent_hocon_reference.md#toolbox).

The value for each key is a dictionary describing the tool's properties. The schema differs slightly between
`langchain tools` and `coded tools`, as detailed below.

### Langchain Tools

These tools extend from the Langchain's `BaseTool` class.

> [!IMPORTANT]
> The former default HTTP tools (`requests_get`, `requests_post`, `requests_put`, `requests_patch`,
> `requests_delete`, and `requests_toolkit`) have been **removed** from the default toolbox. They were built on the
> sunset [langchain-community](https://github.com/langchain-ai/langchain-community/issues/674) package and shipped
> with `allow_dangerous_requests=true`. Operators who need HTTP tools must now define them in their own toolbox
> info file (see [Extending Toolbox Info](#extending-toolbox-info)), which makes any dangerous-request opt-in an
> explicit, informed decision. When such a tool is reachable from untrusted input, prefer an implementation that
> by default denies requests to link-local/cloud-metadata addresses (e.g. `169.254.169.254`) and private
> (RFC 1918) ranges. For maintained tools, see the
> [LangChain tool integrations](https://docs.langchain.com/oss/python/integrations/tools).

#### `class`

Fully qualified class name of the tool. It must exist in the server's `PYTHONPATH` and must have at least
three dot-separated segments: `<package_name>.<module_name>.<ClassName>`. Point at the module that actually
defines the class — the shorter top-level re-export that many integration packages offer
(e.g. `langchain_tavily.TavilySearch`) is rejected.

Example:

```hocon
"class": "langchain_tavily.tavily_search.TavilySearch"
```

If the class is a Langchain **toolkit**, it must implement a `get_tools()` method. When instantiated,
the toolkit returns a list of individual tools via this method — each of which will be available for the agent to call.

#### `args` *(optional)*

A dictionary of arguments for tool initialization.

If **omitted**, the tool class will be instantiated with its default constructor (i.e., no arguments).

Example:

```hocon
"args": {
    "max_results": 5
}
```

May include nested configurations: an argument value that is itself a dictionary with a `class` key
(same three-segment form as [`class`](#class) above) is instantiated (with its own `args`) and passed
as an argument to the outer tool.

Example:

```hocon
"some_tool": {
    "class": "some_integration_package.tools.SomeTool",
    "args": {
        "api_wrapper": {
            "class": "some_integration_package.utilities.SomeApiWrapper",
            "args": {
                "timeout": 30
            }
        }
    }
}
```

This instantiates `SomeTool(api_wrapper=SomeApiWrapper(timeout=30))`.

> [!NOTE]
> If the tool class defines a `from..._api_wrapper` classmethod (several langchain toolkits do, e.g.
> `GitHubToolkit.from_github_api_wrapper`), the factory calls that classmethod instead of the constructor,
> and the argument names must match the classmethod's signature — for `GitHubToolkit` that argument is
> `github_api_wrapper`, not `api_wrapper`.

#### `base_tool_info_url` *(optional)*

Reference URL pointing to Langchain’s documentation for the specific tool.

This field is for user reference only—**it is not used by the system** during tool loading or execution.

#### `display_as` *(optional)*

Display type for clients. Options:

- `"coded_tool"`
- `"external_agent"`
- `"langchain_tool"` (default)
- `"llm_agent"`
  
  If **not provided**, the tool is inferred as `"langchain_tool"` unless it contains a [`description`](#description).

### Coded Tools

These tools extend from the `CodedTool` class.

#### [`class`](./agent_hocon_reference.md#class)

Fully qualified class name in the format `tool_module.ToolClass`. The `class` must point to a module available in your
`AGENT_TOOL_PATH` and server `PYTHONPATH`. When the `AGENT_TOOL_PATH_ONLY` environment variable is `true`,
fully-qualified references are not resolved at all — even ones pointing inside `AGENT_TOOL_PATH` — so a shared coded
tool's `class` must be given relative to the `AGENT_TOOL_PATH` hierarchy (`tool_module.ToolClass`), not as its full
package path.

Example:

```hocon
"class": "get_current_date_time.GetCurrentDateTime"
```

#### [`description`](./agent_hocon_reference.md#description)

A plain-language explanation of the tool’s behavior. This is essential for agents to understand how and when to use the tool.

#### [`parameters`](./agent_hocon_reference.md#parameters) *(optional)*

JSON schema-like structure describing the expected input arguments, types, and which are required.

If this field is **absent**, the LLM will simply call the tool **without providing any arguments**.

Example:

```hocon
"parameters": {
    "type": "object",
    "properties": {
        "query": {
            "type": "string",
            "description": "The search query"
        }
    },
    "required": ["query"]
}
```

<!--- pyml disable-next-line no-duplicate-heading -->
#### `display_as` *(optional)*

Display type for clients. Options:

- `"coded_tool"` (default)
- `"external_agent"`
- `"langchain_tool"`
- `"llm_agent"`

If **omitted**, tools with a `description` are treated as `"coded_tool"`; otherwise, `"langchain_tool"`.

---

## Extending Toolbox Info

To customize the set of tools available to agents in the neuro-san system, you can provide your own toolbox info file.
This allows you to add, override, or refine tool definitions beyond what's included by default, and can be done in two ways:

### `AGENT_TOOLBOX_INFO_FILE` Environment Variable

You can configure a global toolbox info file for all agents by setting the `AGENT_TOOLBOX_INFO_FILE` environment variable:

```bash
export AGENT_TOOLBOX_INFO_FILE=/path/to/your/toolbox_info.hocon
```

This method is ideal for system-wide setups where multiple agents share the same toolset.
It lets you apply changes across the board without editing each agent configuration individually.

### `toolbox_info_file` Keys in Agent Network HOCON

If you need more flexibility, you can specify a custom toolbox file directly in an agent’s HOCON config
using [`toolbox_info_file`](./agent_hocon_reference.md#toolbox_info_file) key.

This per-agent setting overrides any value set via the `AGENT_TOOLBOX_INFO_FILE` environment variable.
This is useful when individual agents require specialized or isolated tool configurations.
