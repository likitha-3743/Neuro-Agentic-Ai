# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

import logging
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from tests.load_tests.load_test_constants import SEPARATOR_WIDTH
from tests.load_tests.reporting.table_formatter import TableFormatter

logger: logging.Logger = logging.getLogger(__name__)


class PoolAnalyzer:
    """
    Analyzes executor thread pool reuse across load test stages.

    Holds the collected stage summaries for analysis.
    """

    def __init__(self, stage_summaries: List[Dict[str, Any]]) -> None:
        """
        Constructor.

        :param stage_summaries: Per-stage summaries collected during the run
        """
        self._summaries: List[Dict[str, Any]] = stage_summaries

    # pylint: disable=too-many-locals
    def log_pool_reuse_analysis(self) -> None:
        """
        Log executor pool reuse analysis across stages.
        """
        stages_with_data: List[Dict[str, Any]] = []
        stage_summary: Dict[str, Any]
        # Keep the stages that have both thread counts and at least one server call.
        for stage_summary in self._summaries:
            if stage_summary.get("before_threads") is None or stage_summary.get("after_threads") is None:
                continue
            total_started: Optional[int] = stage_summary.get("total_started")
            if total_started is not None and total_started > 0:
                stages_with_data.append(stage_summary)
        if not stages_with_data:
            return

        base_threads: int = stages_with_data[0].get("before_threads")

        logger.info("\n%s", "=" * SEPARATOR_WIDTH)
        logger.info("  EXECUTOR POOL REUSE ANALYSIS")
        logger.info("=" * SEPARATOR_WIDTH)

        header: List[str] = [
            "Batch", "Server Calls", "New Threads",
            "Peak Threads", "Reused", "Reuse%",
            "Pool Avail", "Exec/Req",
        ]
        rows: List[List[str]] = []
        total_new_threads: int = 0
        reuse_percentages: List[float] = []

        index: int
        stage: Dict[str, Any]
        # One table row per stage.
        for index, stage in enumerate(stages_with_data):
            batch_number: int = index + 1
            server_calls: int = stage.get("total_started")
            before_threads: int = stage.get("before_threads")
            after_threads: int = stage.get("after_threads")
            new_threads: int = max(after_threads - before_threads, 0)
            total_new_threads += new_threads
            reused: int = max(server_calls - new_threads, 0)
            reuse_percentage: float = 0.0
            if server_calls > 0:
                reuse_percentage = reused / server_calls * 100.0
            reuse_percentages.append(reuse_percentage)
            pool_available_threads: int = max(before_threads - base_threads, 0)

            primary_requests: int = stage.get("primary_started") or stage.get("concurrent")
            executors_per_request: float = 0.0
            if primary_requests > 0:
                executors_per_request = server_calls / primary_requests

            peak_threads: Optional[int] = stage.get("peak_threads")
            peak_threads_text: str = "-"
            if peak_threads is not None:
                peak_threads_text = str(peak_threads)

            row: List[str] = [
                str(batch_number),
                str(server_calls),
                f"+{new_threads}",
                peak_threads_text,
                str(reused),
                f"{reuse_percentage:.1f}%",
                str(pool_available_threads),
                f"{executors_per_request:.1f}",
            ]
            rows.append(row)

        TableFormatter.log_table(header, rows)

        first_demand: int = max(stages_with_data[0].get("after_threads") - stages_with_data[0].get("before_threads"), 0)
        self._log_pool_diagnostics(reuse_percentages, total_new_threads, first_demand=first_demand)

    @staticmethod
    def _log_pool_diagnostics(reuse_percentages: List[float], total_new_threads: int, first_demand: int) -> None:
        """
        Log summary diagnostics for pool reuse.

        :param reuse_percentages: Pool reuse percent of each batch, in order
        :param total_new_threads: New threads created across all batches
        :param first_demand: Thread demand of the first batch
        """
        if len(reuse_percentages) < 2:
            return
        logger.info(
            "\n  Pool reuse: %.1f%% (batch 1) -> %.1f%% (batch %d)",
            reuse_percentages[0], reuse_percentages[-1], len(reuse_percentages),
        )
        if total_new_threads > first_demand > 0:
            excess: int = total_new_threads - first_demand
            logger.info(
                "  WARNING: %d new threads created across all batches, but batch 1 demand was only %d.",
                total_new_threads, first_demand,
            )
            logger.info("           %d excess threads indicate pool lock contention in return_executor().", excess)
            logger.info("           cancel_current_tasks() holds the pool lock for up to 5s, blocking reuse.")
