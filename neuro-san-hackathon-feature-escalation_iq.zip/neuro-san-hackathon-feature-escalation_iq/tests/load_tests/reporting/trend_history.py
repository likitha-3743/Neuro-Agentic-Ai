# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

import json
import logging
import os

from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Set

from tests.load_tests.load_test_constants import HISTORY_FILE_NAME
from tests.load_tests.load_test_constants import HISTORY_THRESHOLDS_SECONDS
from tests.load_tests.reporting.table_formatter import TableFormatter

logger: logging.Logger = logging.getLogger(__name__)


class TrendHistory:
    """
    Reads history JSONL records and logs them in run order.

    Complements the cross-run comparison, which answers a different
    question: that one groups runs by request count to show how the system
    scales, while this one keeps runs in the order they happened so a
    regression between neuro-san versions is visible.
    """

    def __init__(self, path: str, agent_filter: Optional[List[str]] = None) -> None:
        """
        Constructor.

        :param path: History JSONL file, or a directory holding it
        :param agent_filter: Agent names to include; None or empty includes every agent
        """
        self._path: str = path
        self._agent_filter: Set[str] = set()
        if agent_filter:
            self._agent_filter = set(agent_filter)

    def run(self) -> None:
        """
        Read the history file and log one row per recorded run.
        """
        history_path: Optional[str] = self._resolve_path()
        if history_path is None:
            logger.info(
                "No history file found at %s. Runs append one record each, so this file appears after the first run.",
                self._path,
            )
            return
        records: List[Dict[str, Any]] = self._read_records(history_path)
        if not records:
            logger.info("No usable records in %s", history_path)
            return
        record: Dict[str, Any]
        if self._agent_filter:
            # Keep only the records for the agents in the filter.
            matching_records: List[Dict[str, Any]] = []
            # Keep the records of the agents in the filter.
            for record in records:
                if record.get("agent") in self._agent_filter:
                    matching_records.append(record)
            records = matching_records
            if not records:
                agent_names: str = ", ".join(sorted(self._agent_filter))
                logger.info("No records for agent(s) %s in %s", agent_names, history_path)
                return
        records.sort(key=self._timestamp_of)
        logger.info("")
        logger.info("TREND HISTORY (%s, %s run(s))", history_path, len(records))
        # One table row per record, in file order.
        rows: List[List[str]] = []
        # One table row per record.
        for record in records:
            rows.append(self._row(record))
        TableFormatter.log_table(self._header(), rows)
        logger.info("")

    @staticmethod
    def _timestamp_of(record: Dict[str, Any]) -> str:
        """
        Sort key: the timestamp of a history record.

        :param record: One history record
        :return: The record's "timestamp", "" if missing
        """
        return record.get("timestamp", "")

    def _resolve_path(self) -> Optional[str]:
        """
        Return the history file to read, or None when absent.

        Accepts either the file itself or a directory holding the
        default-named history file, so the path printed at the end of a
        run and its parent output directory both work.

        :return: Path of the history file, or None when absent
        """
        if os.path.isfile(self._path):
            return self._path
        candidate: str = os.path.join(self._path, HISTORY_FILE_NAME)
        if os.path.isfile(candidate):
            return candidate
        return None

    @staticmethod
    def _read_records(history_path: str) -> List[Dict[str, Any]]:
        """
        Parse the JSONL file, skipping unreadable lines.

        A partially written final line is expected when a run is
        interrupted, so a bad line is reported and skipped rather than
        losing every earlier record.

        :param history_path: Path of the history JSONL file
        :return: Every record that is a JSON object, in file order; empty when the file cannot be read
        """
        records: List[Dict[str, Any]] = []
        skipped: int = 0
        try:
            with open(history_path, "r", encoding="utf-8") as file_handle:
                line: str
                # Parse each non-empty line as one JSON record.
                for line in file_handle:
                    line = line.strip()
                    if not line:
                        continue
                    record: Any = None
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        skipped += 1
                        continue
                    if isinstance(record, dict):
                        records.append(record)
                    else:
                        skipped += 1
        except OSError as exc:
            logger.warning("Could not read history file %s: %s", history_path, exc)
            return []
        if skipped:
            logger.warning("  Skipped %s unreadable line(s) in %s", skipped, history_path)
        return records

    @staticmethod
    def _header() -> List[str]:
        """
        Return the table header, including a column per threshold.

        :return: Column names
        """
        header: List[str] = ["timestamp", "neuro-san", "agent", "mode", "via", "reqs", "done"]
        threshold: int
        # One column per threshold, e.g. "<30s".
        for threshold in HISTORY_THRESHOLDS_SECONDS:
            header.append(f"<{int(threshold)}s")
        header.extend(["first_resp", "avg", "wall", "err", "warn"])
        return header

    @staticmethod
    def _row(record: Dict[str, Any]) -> List[str]:
        """
        Format one history record as a table row.

        Client and server-only records count requests under different
        keys, and a server log cannot measure the client's time to
        first response, so the missing values render as "-".

        The transport is shown so historical transport values remain
        distinguishable in the same file.

        :param record: One history record
        :return: Cell values in _header order
        """
        mode: str = record.get("mode", "client")
        requests: int = record.get("total_requests", record.get("expected_requests", 0))
        completed: int = record.get("completed", record.get("received_requests", 0))
        row: List[str] = [
            TrendHistory._fmt_timestamp(record.get("timestamp", "")),
            record.get("neuro_san_version", "unknown"),
            record.get("agent", "unknown"),
            mode,
            record.get("transport", "-"),
            str(requests),
            str(completed),
        ]
        threshold: int
        # One cell per threshold: requests completed within it, or "-".
        for threshold in HISTORY_THRESHOLDS_SECONDS:
            threshold_key: str = f"completed_within_{int(threshold)}s"
            completed_count: Any = record.get(threshold_key, "-")
            row.append(str(completed_count))
        row.append(TrendHistory._fmt_seconds(record.get("avg_first_response_s")))
        row.append(TrendHistory._fmt_seconds(record.get("avg_duration_s")))
        row.append(TrendHistory._fmt_seconds(record.get("wall_time_s")))
        row.append(str(record.get("server_error_count", "-")))
        row.append(str(record.get("tool_warning_count", "-")))
        return row

    @staticmethod
    def _fmt_timestamp(timestamp: str) -> str:
        """
        Shorten an ISO timestamp to "YYYY-MM-DD HH:MM".

        :param timestamp: ISO timestamp, or empty
        :return: e.g. '2026-09-30 01:54', or '-' when empty
        """
        if not timestamp:
            return "-"
        text: str = str(timestamp).replace("T", " ")
        return text[:16]

    @staticmethod
    def _fmt_seconds(duration_seconds: Optional[float]) -> str:
        """
        Format a seconds value, rendering absent or zero as "-".

        :param duration_seconds: Seconds, or None
        :return: e.g. '12.3s', or '-' when absent or 0
        """
        if not isinstance(duration_seconds, (int, float)) or duration_seconds <= 0:
            return "-"
        return f"{duration_seconds:.1f}s"
