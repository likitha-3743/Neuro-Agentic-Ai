# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

"""
Agent profile — agent-specific prompts and response checks.

Built by AgentProfileFactory; this class only carries the data.
"""

import logging
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from tests.load_tests.validation.load_test_abort_error import LoadTestAbortError

logger: logging.Logger = logging.getLogger(__name__)


class AgentProfile:
    """
    The test material for one agent under load: what to send it and how
    to judge what comes back. Not a manifest; it does not list files.

    Contents (all optional, read via the get_*() accessors):
      prompts                      - texts sent, one per request, cycled
      responses                    - test-case hocon "response" checks,
                                     parallel to prompts
      failure_patterns             - substrings that turn CREATED into FAILED
      success_fields               - JSON profiles only; sly_data keys that
                                     must come back non-empty
      estimated_tokens_per_request - for the cost estimate
      primary_start_pattern /      - regexes locating this agent's requests
      primary_finish_pattern         in the server log

    Source: AgentProfileFactory builds it either from
    prompts/profiles/<agent>.json or from the test-case hocon files in
    <fixtures-hocon-dir>/<agent>/*.hocon (one prompt + response per file).

    Use: TrafficRunner takes the prompt and response checks for each
    request; LoadTestOrchestrator takes the log patterns and token
    estimate.
    """

    def __init__(self, agent_name: str, profile: Dict[str, Any]) -> None:
        """
        Keep the profile dict built by AgentProfileFactory.

        :param agent_name: Name of the agent under test
        :param profile: The profile as a dict with the keys listed in the class docstring
        """
        self.agent_name: str = agent_name
        self._profile: Dict[str, Any] = profile

    def get_prompts(self) -> List[str]:
        """
        :return: The list of prompts for this agent
        """
        return self._profile.get("prompts", [])

    def get_estimated_tokens_per_request(self) -> Optional[int]:
        """
        :return: The estimated token usage per request, or None if unknown
        """
        return self._profile.get("estimated_tokens_per_request")

    def get_primary_start_pattern(self) -> str:
        """
        :return: Regex pattern to identify primary request starts in the server log
        """
        default: str = f"Start {self.agent_name}/streaming_chat"
        return self._profile.get("primary_start_pattern", default)

    def get_primary_finish_pattern(self) -> str:
        """
        :return: Regex pattern to identify primary request completions in the server log
        """
        default: str = f"Finish {self.agent_name}/streaming_chat"
        return self._profile.get("primary_finish_pattern", default)

    def get_success_fields(self) -> List[str]:
        """
        Only JSON profiles carry this; AgentProfileFactory turns it into
        the equivalent `responses` block, which is what TrafficRunner
        checks. Hocon profiles state their checks in `responses` directly.

        :return: The JSON profile's sly_data keys that must come back non-empty
        """
        return self._profile.get("success_fields", [])

    def get_responses(self) -> List[Dict[str, Any]]:
        """
        Each entry is a test-case hocon "response" block (text /
        structure / sly_data with AgentEvaluator checks such as
        keywords, value, not_value, gist). See
        docs/test_case_hocon_reference.md. A JSON profile gets one
        block, built from its success_fields, shared by all prompts.

        :return: The per-prompt response checks, parallel to prompts
        """
        return self._profile.get("responses", [])

    def get_failure_patterns(self) -> List[str]:
        """
        When any pattern is found in the answer text, a request that would
        otherwise be marked CREATED is downgraded to FAILED.  This
        catches cases where the server returns an error message
        inside a successful HTTP 200 response (e.g. missing API key).

        :return: Substrings that indicate a failed response
        """
        return self._profile.get("failure_patterns", [])

    def get_prompt(self, request_id: int, same_prompt: bool = False, allow_caching: bool = False) -> str:
        """
        Return the prompt for a given request.

        In same_prompt mode, always returns the first prompt.
        In varied mode, cycles through the pool and appends the request_id.
        The request_id suffix keeps every prompt unique so that no
        cache along the path (LLM prompt cache, agent network, proxy)
        can serve the response.  In allow_caching mode the suffix is
        dropped, so requests that reuse a pool prompt are eligible
        for those caches.

        :param request_id: Global request number, used to cycle through the pool
        :param same_prompt: When True every request uses the first prompt
        :param allow_caching: When True the unique request_id suffix is not added
        :return: The prompt text to send
        :raises LoadTestAbortError: With exit code 1 when the profile has no prompts
        """
        prompts: List[str] = self.get_prompts()
        if not prompts:
            logger.error(
                """Agent profile '%s' has an empty prompts list.
  Add at least one prompt to the profile JSON.
  Aborting.""",
                self.agent_name,
            )
            raise LoadTestAbortError(1)
        base_prompt: str = prompts[self._pool_index(request_id, same_prompt, len(prompts))]
        if allow_caching:
            return base_prompt
        # The suffix makes every prompt unique, so no cache along the
        # path (LLM prompt cache, agent network, proxy) can serve the
        # response and the run measures real work, not cache hits.
        return f"{base_prompt} (request {request_id})"

    def get_response(self, request_id: int, same_prompt: bool = False) -> Dict[str, Any]:
        """
        Return the response checks for the prompt get_prompt() gives request_id.

        :param request_id: Global request number, used to cycle through the pool
        :param same_prompt: When True every request uses the first entry
        :return: The hocon ``response`` block, or {} when the profile has none
        """
        responses: List[Dict[str, Any]] = self.get_responses()
        if not responses:
            return {}
        return responses[self._pool_index(request_id, same_prompt, len(responses))]

    @staticmethod
    def _pool_index(request_id: int, same_prompt: bool, pool_size: int) -> int:
        """
        Index into a per-prompt pool.

        :param request_id: Global request number
        :param same_prompt: When True always pick the first entry
        :param pool_size: Number of entries in the pool
        :return: 0 in same_prompt mode, else request_id modulo pool_size
        """
        if same_prompt:
            return 0
        # Requests are numbered 0, 1, 2, ... across the whole run, and the
        # pool is usually smaller than the run.  The modulo walks the pool
        # in order so consecutive requests get different prompts, and wraps
        # back to the first entry once every prompt has been used, so the
        # same prompt (and its response checks) recur evenly over a long run.
        return request_id % pool_size
