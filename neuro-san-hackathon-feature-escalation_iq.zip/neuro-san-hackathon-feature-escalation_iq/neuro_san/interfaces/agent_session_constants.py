
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT


class AgentSessionConstants:
    """
    Interface for shared constants between AgentSession and AsyncAgentSession
    """

    # Default port for the Agent HTTP Service
    # This port number will also be mentioned in its Dockerfile
    DEFAULT_HTTP_PORT: int = 8080

    # Default port for https:// references to agents served elsewhere.
    # Unlike the bare http dev server above, an https reference is expected to
    # hit a TLS-terminating proxy or load balancer in front of the server,
    # which listens on the well-known https port rather than on 8080.
    DEFAULT_HTTPS_PORT: int = 443

    DEFAULT_PORT: int = DEFAULT_HTTP_PORT
