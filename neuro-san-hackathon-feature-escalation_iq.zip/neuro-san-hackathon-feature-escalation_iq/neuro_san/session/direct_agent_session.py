
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Any
from typing import Dict
from typing import Generator
from typing import List
from typing import Optional

from asyncio import Task
from contextlib import suppress

from leaf_common.asyncio.async_to_sync_generator import AsyncToSyncGenerator
from leaf_common.asyncio.asyncio_executor import AsyncioExecutor
from leaf_common.parsers.dictionary_extractor import DictionaryExtractor
from leaf_common.time.timeout import Timeout

from neuro_san.interfaces.agent_session import AgentSession
from neuro_san.internals.chat.connectivity_reporter import ConnectivityReporter
from neuro_san.internals.chat.data_driven_chat_session import DataDrivenChatSession
from neuro_san.internals.chat.queue_filter import QueueFilter
from neuro_san.internals.graph.registry.agent_network import AgentNetwork
from neuro_san.internals.interfaces.context_type_toolbox_factory import ContextTypeToolboxFactory
from neuro_san.internals.journals.message_journal import MessageJournal
from neuro_san.session.session_invocation_context import SessionInvocationContext


class DirectAgentSession(AgentSession):
    """
    Service-agnostic guts for a AgentSession.
    This could be used by a Flask/Quart app or a gRPC service.
    """

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def __init__(self,
                 agent_network: AgentNetwork,
                 invocation_context: Optional[SessionInvocationContext],
                 metadata: Dict[str, Any] = None,
                 security_cfg: Dict[str, Any] = None,
                 umbrella_timeout: Timeout = None,
                 # Keyword-only: the sync and async session signatures diverge
                 # above this point, so positional passing would misbind.
                 *,
                 toolbox_factory: ContextTypeToolboxFactory = None):
        """
        Constructor

        :param agent_network: The AgentNetwork to use for the session.
        :param invocation_context: The SessionInvocationContext to use to consult
                        for policy objects scoped at the invocation level.
                        May be None for sessions that only serve connectivity()
                        or function(); chat methods require a real instance.
        :param metadata: A dictionary of request metadata to be forwarded
                        to subsequent yet-to-be-made requests.
        :param security_cfg: A dictionary of parameters used to
                        secure the TLS and the authentication of the gRPC
                        connection.  Supplying this implies use of a secure
                        GRPC Channel.  If None, uses insecure channel.
        :param umbrella_timeout: A Timeout object to periodically check in loops.
                        Default is None (no timeout).
        :param toolbox_factory: An optional ContextTypeToolboxFactory built from
                        the same agent network's config, so connectivity reporting
                        does not have to re-read toolbox info files per request.
                        May be passed pre-loaded; connectivity reporting will
                        load() it (a no-op if already loaded).
                        If None, the invocation_context's toolbox factory is used
                        when available; failing that, connectivity reporting
                        builds one from the agent network's config.
        """
        # These aren't used yet
        self._metadata: Dict[str, Any] = metadata
        self._security_cfg: Dict[str, Any] = security_cfg

        self.invocation_context: SessionInvocationContext = invocation_context
        self.agent_network: AgentNetwork = agent_network
        self.request_id: str = None
        self.umbrella_timeout: Timeout = umbrella_timeout
        # Resolve the toolbox factory once at construction: an invocation
        # context's factory is fixed when the context is built, and resolving
        # here keeps connectivity() working even after close() sets
        # self.invocation_context to None.
        self.toolbox_factory: ContextTypeToolboxFactory = toolbox_factory
        if self.toolbox_factory is None and invocation_context is not None:
            self.toolbox_factory = invocation_context.get_toolbox_factory()
        if metadata is not None:
            self.request_id = metadata.get("request_id")

    def function(self, request_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        :param request_dict: A dictionary version of the FunctionRequest
                    protobufs structure. Has the following keys:
                        <None>
        :return: A dictionary version of the FunctionResponse
                    protobufs structure. Has the following keys:
                "function" - the dictionary description of the function
        """
        _ = request_dict
        response_dict: Dict[str, Any] = {}

        front_man: str = self.agent_network.find_front_man()
        if front_man is not None:
            spec: Dict[str, Any] = self.agent_network.get_agent_tool_spec(front_man)
            empty: Dict[str, Any] = {}
            function: Dict[str, Any] = spec.get("function", empty)
            response_dict = {
                "function": function,
            }

        return response_dict

    def connectivity(self, request_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        :param request_dict: A dictionary version of the ConnectivityRequest
                    protobufs structure. Has the following keys:
                        <None>
        :return: A dictionary version of the ConnectivityResponse
                    protobufs structure. Has the following keys:
                "connectivity_info" - the list of connectivity descriptions for
                                    each node in the agent network the service
                                    wants the client ot know about.
        """
        _ = request_dict

        reporter = ConnectivityReporter(self.agent_network, self.toolbox_factory)
        config: Dict[str, Any] = self.agent_network.get_config()
        metadata: Dict[str, Any] = config.get("metadata")
        connectivity_info: List[Dict[str, Any]] = reporter.report_network_connectivity()
        response_dict: Dict[str, Any] = {
            "connectivity_info": connectivity_info,
        }
        if metadata is not None:
            response_dict["metadata"] = metadata

        return response_dict

    # pylint: disable=too-many-locals,too-many-statements,too-many-branches
    def streaming_chat(self, request_dict: Dict[str, Any]) -> Generator[Dict[str, Any], None, None]:
        """
        :param request_dict: A dictionary version of the ChatRequest
                    protobufs structure. Has the following keys:
            "user_message" - A ChatMessage dict representing the user input to the chat stream
            "chat_context" - A ChatContext dict representing the state of the previous conversation
                            (if any)

        :return: An iterator of dictionary versions of the ChatResponse
                    protobufs structure. Has the following keys:
            "response"      - An optional ChatMessage dictionary.  See chat.proto for details.

            Note that responses to the chat input might be numerous and will come as they
            are produced until the system decides there are no more messages to be sent.
        """
        extractor = DictionaryExtractor(request_dict)

        # Get the user input.
        user_input: str = extractor.get("user_message.text")

        # Create the gateway to the internals.
        chat_session = DataDrivenChatSession(agent_network=self.agent_network)

        # Prepare the response dictionary
        template_response_dict: Dict[str, Any] = {}

        if chat_session is None or user_input is None:
            # Can't go on to chat, so report back early with a single value.
            # There is no ChatMessage response in the dictionary in this case
            yield template_response_dict
            return

        # Create a message filter so as to minimize network traffic per what the user wants
        chat_filter: Dict[str, Any] = request_dict.get("chat_filter")
        chat_context: Dict[str, Any] = request_dict.get("chat_context")
        sly_data: Dict[str, Any] = request_dict.get("sly_data")

        # Task for late-stage conversions for any and all messages
        queue_filter = QueueFilter(chat_filter, self.agent_network)
        message_journal: MessageJournal = self.invocation_context.get_journal()
        queue_filter.apply_to_journal(message_journal)

        # Create an asynchronous background task to process the user input.
        # This might take a few minutes, which can be longer than some
        # sockets stay open.
        asyncio_executor: AsyncioExecutor = self.invocation_context.get_asyncio_executor()
        task: Task = asyncio_executor.submit(self.request_id, chat_session.streaming_chat,
                                             user_input, self.invocation_context, sly_data,
                                             chat_context)
        # Ignore the future. Live in the now.
        _ = task

        # The synchronously_iterate() method below will synchronously block waiting for
        # chat.ChatMessage dictionaries to come back asynchronously from the submit()
        # above until there are no more from the input.
        empty: Dict[str, Any] = {}
        generator = AsyncToSyncGenerator(asyncio_executor, self.request_id,
                                         generated_type=Dict,
                                         keep_alive_result=empty,
                                         keep_alive_timeout_seconds=10.0,
                                         umbrella_timeout=self.umbrella_timeout)
        try:
            # Logic of what is done here:
            # 1. We tell underlying chat_session to delete its resources since we are done with this request;
            # 2. We do this in "finally" block so this releasing of resources happens in any case,
            #    including getting our sync generator
            #    (which is implicitly constructed by these code lines and returned by this method)
            #    interrupted by caller-side "close" method.
            # 3. And we suppress all exceptions while deleting resources to keep things quieter.
            message: Dict[str, Any] = None
            for message in generator.synchronously_iterate(self.invocation_context.get_queue()):
                if message is not None:
                    yield message
        finally:
            # Release resources without exceptions
            with suppress(Exception):
                # Cannot run as if in sync environment, so run async
                # This finish_request() will dole out what is appropriate to run in the
                # executor vs in the current thread.
                self.invocation_context.finish_request()

    def reset(self):
        """
        Allows for re-use of the same instance for clients
        """
        self.invocation_context.reset()

    def close(self):
        """
        Tears down resources created
        """
        if self.invocation_context is None:
            return

        self.invocation_context.finish_request()
        self.invocation_context = None

    def is_closed(self) -> bool:
        """
        :return: True if close() has been called on this session, in which case
                 further streaming_chat()/function()/connectivity() calls raise
                 AgentSessionClosedError. The default is False for sessions that
                 hold no external connection and therefore cannot be closed.
        """
        return False
