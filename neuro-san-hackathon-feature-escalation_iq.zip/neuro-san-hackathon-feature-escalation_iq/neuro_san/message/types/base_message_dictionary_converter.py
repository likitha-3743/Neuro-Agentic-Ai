
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Union

from logging import getLogger
from logging import Logger

from langchain_core.messages.ai import AIMessage
from langchain_core.messages.base import BaseMessage
from langchain_core.messages.human import HumanMessage
from langchain_core.messages.system import SystemMessage
from langchain_core.messages.tool import ToolMessage

from leaf_common.serialization.interface.dictionary_converter import DictionaryConverter

from neuro_san.message.content_blocks.content_blocks_format import ContentBlocksFormat
from neuro_san.message.content_blocks.content_blocks_format_registry import ContentBlocksFormatRegistry
from neuro_san.message.types.agent_message import AgentMessage
from neuro_san.message.types.agent_framework_message import AgentFrameworkMessage
from neuro_san.message.types.agent_progress_message import AgentProgressMessage
from neuro_san.message.types.agent_tool_result_message import AgentToolResultMessage
from neuro_san.message.types.chat_message_type import ChatMessageType
from neuro_san.message.types.chat_message_type_util import ChatMessageTypeUtil
from neuro_san.message.utils.content_utils import ContentUtils


class BaseMessageDictionaryConverter(DictionaryConverter):
    """
    A DictionaryConverter implementation which can convert langchain BaseMessages
    back and forth to our own ChatMessage dictionary format (as defined in chat.proto).
    """

    # The ChatMessageTypes that from_dict rebuilds for a model's chat history,
    # whatever langchain_only says.
    CHAT_HISTORY_TYPES: List[ChatMessageType] = [
        ChatMessageType.SYSTEM,
        ChatMessageType.HUMAN,
        ChatMessageType.AI,
        ChatMessageType.AGENT_TOOL_RESULT,
    ]

    def __init__(self, origin: List[Dict[str, Any]] = None,
                 langchain_only: bool = True):
        """
        Constructor

        :param origin: A List of origin dictionaries indicating the origin of the run.
            The origin can be considered a path to the original call to the front-man.
            Origin dictionaries themselves each have the following keys:
                "tool"                  The string name of the tool in the spec
                "instantiation_index"   An integer indicating which incarnation
                                        of the tool is being dealt with.
            This is only used for to_dict()
        :param langchain_only: When True (default) only convert langchain messages,
                        and not our own special variants, because the result is bound
                        for a model's chat history. Reasoning blocks are then held
                        back as well (see from_dict).
            This is only used for from_dict()
        """
        self.origin: List[Dict[str, Any]] = origin
        self.langchain_only: bool = langchain_only

    def to_dict(self, obj: BaseMessage) -> Dict[str, Any]:
        """
        Convert the BaseMessage to a chat.ChatMessage dictionary.

        text always carries the flattened text. Block content that says more
        than its text (reasoning, images, several text blocks, provider extras,
        ...) also rides in content_blocks, the format-tagged wrapper from
        chat.proto. Content that normalizes to a plain string (see
        ContentUtils.normalize_content) carries no content_blocks key, so
        text-only traffic keeps its exact shape.

        :param obj: The BaseMessage to convert
        :return: The ChatMessage in dictionary form
        """

        message: BaseMessage = obj
        message_type: ChatMessageType = ChatMessageTypeUtil.from_message(message)
        chat_message: Dict[str, Any] = {
            "type": message_type,
            # No mime_data for now
        }

        # Handle the origin information if we have it
        if self.origin is not None:
            chat_message["origin"] = self.origin

        # Dictionary of BaseMessage field sources to ChatMessage destinations
        # Anything in this dictionary is considered optional and we only populate
        # the field on ChatMessage if it has a value.
        optionals: Dict[str, str] = {
            "content": "text",
            "chat_context": "chat_context",
            "tool_result_origin": "tool_result_origin",
            "structure": "structure",
            "sly_data": "sly_data",
        }
        content_blocks: Optional[Dict[str, Any]] = None
        src: str = None
        dest: str = None
        for src, dest in optionals.items():
            value: Any = None
            try:
                value = getattr(message, src)
            except AttributeError:
                # Not all BaseMessage subclasses have every field we are looking
                # for, and that is ok.
                value = None

            # Content is a plain string for most providers, but can be a list
            # of content blocks (e.g. Anthropic thinking + text, or list-of-str,
            # which is also legal per the BaseMessage annotation). Project list
            # content to its full text: concatenate every text block, not just
            # the first one - a thinking-first response has no text in its
            # first block at all.
            if src == "content" and isinstance(value, list):
                if len(value) == 0:
                    # Keep omitting the text key for empty-list content:
                    # emitting text="" instead would make such messages newly
                    # answer-eligible in AnswerMessageFilter and able to
                    # displace the real answer.
                    value = None
                else:
                    # Deliberately NOT gated on ContentUtils.is_empty_content:
                    # blank-but-non-empty block content (e.g. reasoning-only)
                    # already emitted text=""/" " under the old first-block
                    # flatten, and this projection preserves that wire shape
                    # exactly.
                    value = ContentUtils.flatten_to_text(value)
                    content_blocks = self.content_blocks_for(message)

            if value is not None:
                chat_message[dest] = value

        if content_blocks is not None:
            chat_message["content_blocks"] = content_blocks

        return chat_message

    def content_blocks_for(self, message: BaseMessage) -> Optional[Dict[str, Any]]:
        """
        Build the content_blocks wrapper for a message with list content.

        normalize_content collapses a lone text block (and a list of strings)
        to text, so only real block content is wrapped. The provider
        translators it runs raise on malformed blocks (a text block with no
        "text", a non_standard block with no "value", ...) where the text
        projection never did, and they skip content items they do not
        recognize (a bare string inside a block list), which can drop text.
        In both cases the message goes out text-only: the wrapper is only
        emitted while its blocks still flatten to the message's text.

        :param message: A BaseMessage whose content is a non-empty list
        :return: The wrapper dictionary, or None when the content is only text
                 or could not be standardized without losing text
        """
        logger: Logger = getLogger(self.__class__.__name__)
        normalized: Union[str, List[Dict[str, Any]]] = None
        try:
            normalized = ContentUtils.normalize_content(message)
        except (KeyError, ValueError, TypeError, AttributeError) as exception:
            logger.warning("Could not standardize the block content of a %s; sending its text only: %s",
                           message.__class__.__name__, exception)
            return None

        if not isinstance(normalized, list):
            return None

        use_normalized: List[Dict[str, Any]] = normalized
        blocks_text: str = ContentUtils.flatten_to_text(use_normalized)
        message_text: str = ContentUtils.flatten_to_text(message)
        if blocks_text != message_text:
            logger.warning("Standardizing the block content of a %s lost text; sending its text only",
                           message.__class__.__name__)
            return None

        # The wrapper is named after the format the message's blocks are in.
        blocks_format: ContentBlocksFormat = ContentBlocksFormatRegistry.format_for_message(message)
        return ContentUtils.wrap_content_blocks(normalized, blocks_format)

    def from_dict(self, obj_dict: Dict[str, Any]) -> BaseMessage:
        """
        The intended use for this method is for converting a neuro-san ChatMessage
        dictionary into a langchain BaseMessage such that it can be understood by
        a langchain agent within the context of a langchain-facing chat history.
        This means that some special messages we might have inserted into a chat
        history *might* need to be converted into something langchain agents will
        understand.

        The content is the message's text, unless its content_blocks wrapper
        restores to block content (see ContentUtils.restorable_blocks). Then
        the blocks are the content, and the message is marked as carrying
        standard blocks. With langchain_only the message is bound for a
        model's chat history, so reasoning blocks are held back until the
        wire says which provider produced them.

        :param obj_dict: A ChatMessage dictionary to convert into BaseMessage
        :return: A BaseMessage that was converted from the input.
                Can return None if conversion could not take place
        """
        chat_message: Dict[str, Any] = obj_dict
        base_message: BaseMessage = None
        if chat_message is None:
            return base_message

        content: str | List[Dict[str, Any]] = chat_message.get("text")
        message_type: str = chat_message.get("type")
        content_blocks: Optional[Dict[str, Any]] = chat_message.get("content_blocks")
        blocks_format: Optional[ContentBlocksFormat] = ContentUtils.content_blocks_format(content_blocks)
        restored_blocks: Optional[List[Dict[str, Any]]] = \
            ContentUtils.restorable_blocks(chat_message, for_chat_history=self.langchain_only)
        if restored_blocks is not None:
            content = restored_blocks
        chat_message_type: ChatMessageType = ChatMessageTypeUtil.from_response_type(message_type)

        if content is None and chat_message_type in self.CHAT_HISTORY_TYPES:
            # Message constructors reject None content, so a message with no
            # text and no block content to restore gets empty text.
            logger: Logger = getLogger(self.__class__.__name__)
            logger.warning("A %s ChatMessage has no text and no block content to restore; using empty content",
                           chat_message.get("type"))
            content = ""

        if chat_message_type == ChatMessageType.SYSTEM:
            base_message = SystemMessage(content=content)
        elif chat_message_type == ChatMessageType.HUMAN:
            base_message = HumanMessage(content=content)
        elif chat_message_type == ChatMessageType.AI:
            base_message = AIMessage(content=content)
        elif chat_message_type == ChatMessageType.AGENT_TOOL_RESULT:
            tool_result_origin: List[Dict[str, Any]] = chat_message.get("tool_result_origin")
            base_message = AgentToolResultMessage(content=content, tool_result_origin=tool_result_origin)

        if base_message is None and not self.langchain_only:
            # convert_to_base_message() is primarily for populating langchain chat history.
            # so handle these other types differently.
            base_message = self.agent_message_from_dict(chat_message, chat_message_type, content)

        # Any other message type we do not want to send to any agent as chat history.

        if base_message is not None and restored_blocks is not None and blocks_format is not None:
            # Mark the content as blocks of the wrapper's format so that later
            # .content_blocks reads pass them through instead of re-translating them.
            update_dict: Dict[str, Any] = {
                "response_metadata": blocks_format.response_metadata_for(base_message),
            }
            base_message = ContentUtils.message_model_copy(base_message, update_dict)

        return base_message

    @staticmethod
    def agent_message_from_dict(chat_message: Dict[str, Any], chat_message_type: ChatMessageType,
                                content: str | List[Dict[str, Any]]) -> Optional[BaseMessage]:
        """
        Rebuild one of neuro-san's own message types from a ChatMessage dictionary.

        :param chat_message: The ChatMessage dictionary
        :param chat_message_type: Its ChatMessageType
        :param content: The content for the message: its text, or restored blocks
        :return: The message, or None for a type that is never rebuilt
        """
        use_content: str | List[Dict[str, Any]] = content
        if use_content is None:
            use_content = ""

        structure: Dict[str, Any] = chat_message.get("structure")
        base_message: Optional[BaseMessage] = None
        if chat_message_type == ChatMessageType.AGENT:
            base_message = AgentMessage(content=use_content, structure=structure)
        elif chat_message_type == ChatMessageType.AGENT_FRAMEWORK:
            # Don't bother passing on chat_context
            base_message = AgentFrameworkMessage(content=use_content)
        elif chat_message_type == ChatMessageType.AGENT_PROGRESS:
            base_message = AgentProgressMessage(content=use_content, structure=structure)
        return base_message

    @staticmethod
    def is_relevant_to_chat_history(base_message: BaseMessage) -> bool:
        """
        :param base_message: The BaseMessage to consider
        :return: True if the BaseMessage type is relevant to chat history (include).
                 False otherwise (do not include).
        """
        if isinstance(base_message, (AgentMessage, AgentFrameworkMessage, ToolMessage, AgentProgressMessage)):
            # These guys cannot be in chat history as langchain will not recognize them.
            return False
        return True
