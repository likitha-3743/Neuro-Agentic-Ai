
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
from typing import Any
from typing import Dict

from abc import abstractmethod

from leaf_common.utils.interface import interface


@interface
class AgentNetworkInspector:
    """
    Interface describing an entity that can examine the configuration of the
    agent network spec.
    Having this interface breaks some circular dependencies.
    """

    @abstractmethod
    def get_config(self) -> Dict[str, Any]:
        """
        :return: The entire config dictionary given to the instance.
        """
        raise NotImplementedError

    @abstractmethod
    def get_agent_tool_spec(self, name: str) -> Dict[str, Any]:
        """
        :param name: The name of the agent tool to get out of the registry
        :return: The dictionary representing the spec registered agent
        """
        raise NotImplementedError

    @abstractmethod
    def get_name_from_spec(self, agent_spec: Dict[str, Any]) -> str:
        """
        :param agent_spec: A single agent to register
        :return: The agent name as per the spec
        """
        raise NotImplementedError

    @abstractmethod
    def get_network_name(self) -> str:
        """
        :return: The name of the agent network these specs belong to, as it is
                 registered in the manifest (for example "deep/math_guy"), which
                 is also how its hocon file is found. Messages use it to tell the
                 reader where a problem has to be fixed.
        """
        raise NotImplementedError

    @abstractmethod
    def find_front_man(self) -> str:
        """
        :return: A single tool name to use as the root of the chat agent.
                 This guy will be user facing.  If there are none or > 1,
                 an exception will be raised.
        """
        raise NotImplementedError

    @abstractmethod
    def get_size_in_bytes(self) -> int:
        """
        :return: The size in bytes of this AgentNetwork
        """
        raise NotImplementedError
