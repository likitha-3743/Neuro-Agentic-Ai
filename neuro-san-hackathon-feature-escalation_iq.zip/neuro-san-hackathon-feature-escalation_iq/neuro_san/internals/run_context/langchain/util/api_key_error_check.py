
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Any
from typing import Dict
from typing import List
from typing import Optional

# Dictionary with provider key env var -> strings to look for
API_KEY_EXCEPTIONS: Dict[str, List[str]] = {
    "OPENAI_API_KEY": ["OPENAI_API_KEY", "Incorrect API key provided"],
    "ANTHROPIC_API_KEY": ["ANTHROPIC_API_KEY", "anthropic_api_key", "invalid x-api-key", "credit balance"],
    "GOOGLE_API_KEY": ["Application Default Credentials", "default credentials", "Gemini: 400 API key not valid"],

    # OpenRouter surfaces a few distinct families of failures that the friendly
    # OPENROUTER_API_KEY guidance addresses (matches the
    # "1) double-check key / 2) get a key / 3) low credit balance" trio):
    #   * Construction-time: ChatOpenRouter's pydantic validator raises with the
    #     literal text "OPENROUTER_API_KEY must be set." (wrapped in a
    #     pydantic_core.ValidationError, which is in API_KEY_ERRORS).
    #   * Runtime 401 (UnauthorizedResponseError): str() is just the API's error
    #     message — typically "Missing Authentication header" when no key was
    #     sent and provider-defined strings (e.g. "No auth credentials found")
    #     when one was sent but rejected.
    #   * Runtime 402 (PaymentRequiredResponseError): "Insufficient credits..."
    #     with a link to https://openrouter.ai/settings/credits. The same low-
    #     balance bullet in the friendly message applies; matching "Insufficient
    #     credits" plus the OpenRouter settings URL keeps the catch tight.
    "OPENROUTER_API_KEY": ["OPENROUTER_API_KEY", "openrouter_api_key",
                           "Missing Authentication header", "No auth credentials found",
                           "Insufficient credits", "openrouter.ai/settings/credits"],

    # Azure OpenAI. AzureLlmPolicy raises an openai.OpenAIError that names both the llm_config key and
    # the environment variable when the endpoint, credential or deployment cannot be resolved, which
    # is what the *_ENDPOINT / *_API_KEY / *_DEPLOYMENT_NAME and azure_endpoint strings match.
    # "invalid subscription key", "wrong API endpoint", "DeploymentNotFound" and "API deployment for this
    # resource does not exist" are texts Azure itself answers with (the last two are the code and message
    # of the v1 API's 404 for an unknown deployment). Azure's v1 API takes no api-version, so there is no
    # OPENAI_API_VERSION entry.
    "AZURE_OPENAI_API_KEY": ["AZURE_OPENAI_API_KEY", "invalid subscription key", "wrong API endpoint"],
    "AZURE_OPENAI_ENDPOINT": ["azure_endpoint", "AZURE_OPENAI_ENDPOINT"],
    "AZURE_OPENAI_DEPLOYMENT_NAME": ["AZURE_OPENAI_DEPLOYMENT_NAME", "DeploymentNotFound",
                                     "API deployment for this resource does not exist"],
}

AZURE_DOCUMENTATION: str = ("https://learn.microsoft.com/en-us/azure/ai-services/openai/"
                            "chatgpt-quickstart?tabs=keyless%2Ctypescript-keyless%2Cpython-new%2Ccommand-line"
                            "&pivots=programming-language-python")

# Dictionary with provider key env var -> link to documentation
API_KEY_DOCUMENTATION: Dict[str, str] = {
    "AZURE_OPENAI_API_KEY": AZURE_DOCUMENTATION,
    "AZURE_OPENAI_ENDPOINT": AZURE_DOCUMENTATION,
    "AZURE_OPENAI_DEPLOYMENT_NAME": AZURE_DOCUMENTATION,
}

# How a matched key is named in the guidance when plain "X must be set" would mislead: Azure accepts
# any one of three credentials, so the guidance lists them as alternatives.
API_KEY_ALTERNATIVES: Dict[str, str] = {
    "AZURE_OPENAI_API_KEY": "AZURE_OPENAI_API_KEY (or AZURE_OPENAI_AD_TOKEN for a Microsoft Entra token; "
                            "OPENAI_API_KEY is accepted as a fallback)",
}

INTERNAL_ERRORS_LIST: List[str] = ["bound to a different event loop"]


class ApiKeyErrorCheck:
    """
    Class for common policy when checking for API key errors for various LLM providers.
    """

    @staticmethod
    def check_for_api_key_exception(exception: Exception) -> Optional[str]:
        """
        :param exception: An exception to check
        :return: A more helpful exception message if it relates to an API key or None
                if it does not pertain to an API key.
        """

        exception_message: str = str(exception)
        matched_keys: List[str] = []
        matched_documentation_link: str = ""

        # Collect all keys that have any associated string in the exception message
        # since there could be multiple keys with the exact same message.
        api_key: str = None
        string_list: List[str] = None
        for api_key, string_list in API_KEY_EXCEPTIONS.items():
            use_string_list: List[str] = string_list
            find_string: str = None
            for find_string in use_string_list:
                if find_string in exception_message:
                    matched_keys.append(api_key)
                    matched_documentation_link = API_KEY_DOCUMENTATION.get(api_key, "")
                    # No need to check the remaining strings for this key
                    break

        # "AZURE_OPENAI_API_KEY" contains "OPENAI_API_KEY", so an Azure credential error matches the generic
        # OpenAI row too. It is one situation, not two variables to set.
        if "AZURE_OPENAI_API_KEY" in matched_keys and "OPENAI_API_KEY" in matched_keys:
            matched_keys.remove("OPENAI_API_KEY")

        if matched_keys:
            key_names: List[str] = []
            matched_key: str = None
            for matched_key in matched_keys:
                key_names.append(API_KEY_ALTERNATIVES.get(matched_key, matched_key))
            keys_str: str = ", ".join(key_names)
            return f"""
A value for the {keys_str} environment variable must be correctly set in the neuro-san
server or run-time environment in order to use this agent network.

Some things to try:
1) Double check that your value for {keys_str} is set correctly
2) If you do not have a value for {keys_str}, visit the LLM provider's website to get one {matched_documentation_link}
3) It's possible that your credit balance on your account with the LLM provider is too low
   to make the request.  Check that.
4) Sometimes these errors happen because of firewall blockages to the site that hosts the LLM.
   Try checking that you can reach the regular UI for the LLM from a web browser
   on the same machine making this request.
"""

        # No catalogue hit. If this is a pydantic ValidationError, the raw
        # str(exception) can include `input_value=<the user's input>` — which
        # would leak any user-supplied API key value. Rebuild the message from
        # the structured .errors() data instead, omitting the raw input entirely.
        if ApiKeyErrorCheck._is_pydantic_validation_error(exception):
            return ApiKeyErrorCheck._format_redacted_pydantic_error(exception)

        return None

    @staticmethod
    def get_safe_log_message(exception: Exception) -> str:
        """
        Return a log-safe representation of the exception. For pydantic
        ValidationErrors, returns the structured-error-derived message
        (with `input` redacted) so user-supplied values can't leak into
        server logs. For all other exception types, returns str(exception),
        which preserves useful debug detail (status codes, request IDs).
        """
        if ApiKeyErrorCheck._is_pydantic_validation_error(exception):
            return ApiKeyErrorCheck._format_redacted_pydantic_error(exception)
        return str(exception)

    @staticmethod
    def _is_pydantic_validation_error(exception: Exception) -> bool:
        """
        Duck-typed check for pydantic_core.ValidationError to avoid a hard import
        on pydantic_core from this util module.
        """
        cls = type(exception)
        return cls.__name__ == "ValidationError" and cls.__module__.startswith("pydantic")

    @staticmethod
    def _format_redacted_pydantic_error(exception: Exception) -> str:
        """
        Build a message from a pydantic ValidationError using its structured
        .errors() data, redacting the 'input' field entirely so user-supplied
        values can't leak.
        """
        parts: List[str] = []
        err: Dict[str, Any] = None
        for err in exception.errors():
            loc: str = ".".join(str(x) for x in err.get("loc", ()))
            msg: str = err.get("msg", "")
            err_type: str = err.get("type", "")
            parts.append(f"{loc}: {msg} [type={err_type}, input=<redacted>]")
        return f"{len(parts)} validation error(s): " + ";\n".join(parts)

    @staticmethod
    def check_for_internal_error(exception_traceback: str) -> bool:
        """
        Check if exception traceback points to some internal LLM stack problem,
        not necessarily related to API keys being absent or invalid.
        This function used as an additional check while using check_for_api_key_exception()
        :param exception_traceback: exception traceback string;
        :return: True if exception seems to be caused by some internal problems,
                 False otherwise
        """
        err_msg: str = None
        for err_msg in INTERNAL_ERRORS_LIST:
            if err_msg in exception_traceback:
                return True
        return False
