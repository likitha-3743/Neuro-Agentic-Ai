
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
from asyncio import TimeoutError as AsyncTimeout
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Type
from typing import Union

import traceback

from pydantic import ConfigDict

from langchain_core.agents import AgentFinish
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.messages.ai import AIMessage
from langchain_core.messages.ai import AIMessageChunk
from langchain_core.messages.base import BaseMessage
from langchain_core.messages.utils import message_chunk_to_message
from langchain_core.runnables.base import Runnable
from langchain_core.runnables.config import ensure_config
from langchain_core.runnables.config import merge_configs
from langchain_core.runnables.utils import Input
from langchain_core.runnables.utils import Output

from leaf_common.resolution.resolver_util import ResolverUtil

from neuro_san.internals.errors.error_detector import ErrorDetector
from neuro_san.internals.journals.journal import Journal
from neuro_san.internals.journals.origination import Origination
from neuro_san.internals.run_context.interfaces.tool_caller import ToolCaller
from neuro_san.internals.run_context.langchain.journaling.journaling_callback_handler import JournalingCallbackHandler
from neuro_san.internals.run_context.langchain.token_counting.langchain_token_counter import LangChainTokenCounter
from neuro_san.internals.run_context.langchain.tracing.neuro_san_runnable import NeuroSanRunnable
from neuro_san.internals.run_context.langchain.util.api_key_error_check import ApiKeyErrorCheck
from neuro_san.message.types.agent_framework_message import AgentFrameworkMessage
from neuro_san.message.utils.content_utils import ContentUtils

MINUTES: float = 60.0

# Lazily import specific errors from llm providers
RATE_LIMIT_ERROR_TYPES: Tuple[Type[Any], ...] = ResolverUtil.create_type_tuple([
                                            "openai.RateLimitError",
                                            "anthropic.RateLimitError",
                                            "google.genai._interactions.RateLimitError",
                                            # OpenRouter SDK rate-limit error (HTTP 429)
                                            "openrouter.errors.TooManyRequestsResponseError",
                                         ])

# Lazily import specific errors from llm providers
API_ERROR_TYPES: Tuple[Type[Any], ...] = ResolverUtil.create_type_tuple([
                                            "openai.APIError",
                                            "anthropic.APIError",
                                            "langchain_google_genai.chat_models.ChatGoogleGenerativeAIError",
                                            # Base class for all OpenRouter SDK HTTP errors (UnauthorizedResponseError,
                                            # BadGatewayResponseError, ResponseValidationError, etc.). Routing these
                                            # through this branch lets ApiKeyErrorCheck convert runtime 401s
                                            # ("Missing Authentication header") into the friendly OPENROUTER_API_KEY
                                            # message instead of letting them fall through to the generic
                                            # `except Exception` retry.
                                            "openrouter.errors.OpenRouterError",
                                         ])


class RunContextRunnable(NeuroSanRunnable):
    """
    RunnablePassthrough implementation that intercepts journal messages
    """

    # Declarations of member variables here satisfy Pydantic style,
    # which is a type validator that langchain is based on which
    # is able to use JSON schema definitions to validate fields.
    agent_chain: Runnable

    # This needs to be a Runnable because nowadays the primary LLM could be
    # be a BaseLanguageModel with fallbacks attached to it, which ends up
    # being a Runnable.
    primary_llm: Runnable

    journal: Journal

    tool_caller: ToolCaller

    error_detector: ErrorDetector

    session_id: str

    # This guy needs to be a pydantic class and in order to have
    # a non-pydantic Journal as a member, we need to do this.
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # pylint: disable=redefined-builtin
    async def run_it(self, inputs: Input) -> Output:
        """
        Transform a single input into an output.

        Args:
            inputs: The input to the `Runnable`.

        Returns:
            The output of the `Runnable`.
        """

        # Create an agent executor and invoke it with the most recent human message
        # as input.
        agent_spec: Dict[str, Any] = self.tool_caller.get_agent_tool_spec()

        max_execution_seconds: float = agent_spec.get("max_execution_seconds", 5.0 * MINUTES)

        # Langchain `create_agent` uses LangGraph under the hood, which has a default recursion limit of 10,000.
        # Even though it is called "recursion limit", it is actually more of a step ("super-step") limit for
        # the entire graph execution, which includes all calls to tools and LLMs.
        # Nodes that run in parallel are part of the same super-step,
        # while nodes that run sequentially belong to separate super-steps.
        # Note that the documentation states that the default is 1,000 but the code itself has a default of 10,000.
        #
        # Documentation:
        # https://docs.langchain.com/oss/python/langgraph/graph-api#recursion-limit
        # https://docs.langchain.com/oss/python/langgraph/graph-api#graphs
        #
        # Code:
        # https://github.com/langchain-ai/langchain/blob/master/libs/langchain_v1/langchain/agents/factory.py
        # https://github.com/langchain-ai/langgraph/blob/main/libs/langgraph/langgraph/pregel/_loop.py
        max_iterations: int = agent_spec.get("max_iterations")
        if max_iterations is not None:
            self.logger.warning(
                "Agent config for '%s' of '%s' network contains 'max_iterations' which is deprecated. "
                "Please use 'max_steps' instead.",
                self.tool_caller.get_name(),
                self.invocation_context.get_agent_name()
            )
        # Calling the parameter "max_steps" going forward to avoid confusion with the "max_iterations" parameter.
        # Only fall back to "max_iterations" if "max_steps" was not explicitly provided.
        # Default is 10,000 to match the default recursion limit in LangGraph.
        max_steps: int = agent_spec.get("max_steps") or max_iterations or 10_000

        # Create the list of callbacks to pass when invoking
        journaling_callback: JournalingCallbackHandler = JournalingCallbackHandler(
            calling_agent_journal=self.journal,
            base_journal=self.invocation_context.get_journal(),
            parent_origin=self.origin,
            origination=self.invocation_context.get_origination()
        )
        callbacks: List[BaseCallbackHandler] = [
            journaling_callback
        ]

        # Consult the agent spec for level of verbosity as it pertains to callbacks.
        agent_spec: Dict[str, Any] = self.tool_caller.get_agent_tool_spec()
        verbose: Union[bool, str] = agent_spec.get("verbose", False)
        if isinstance(verbose, str):
            verbose_string: str = verbose
            if verbose_string.lower() in ("true", "extra", "logging"):
                # This particular class adds a *lot* of very detailed messages
                # to the logs.  Add this because some people are interested in it.
                # If you find yourself curious about this setting, what you probably
                # are really looking for is an Observability setup like:
                #       LangSmith, Langfuse, HoneyHive, or Arize Phoenix.
                # See the docs for Observability plugins in neuro-san-studio.
                # This was our only tie to langchain-classic, so make it optional in this case.
                # pylint: disable=invalid-name
                LoggingCallbackHandler: Type[BaseCallbackHandler] = ResolverUtil.create_type(
                    "langchain_classic.callbacks.tracers.logging.LoggingCallbackHandler",
                    install_if_missing="langchain-classic"
                )
                callbacks.append(LoggingCallbackHandler(self.logger))

        # Get the number of attempts from the spec.
        max_attempts: int = agent_spec.get("max_attempts", 3)
        max_attempts = max(max_attempts, 1)

        # Prepare our own runnable config
        runnable_config: Dict[str, Any] = self.prepare_runnable_config(callbacks=callbacks,
                                                                       recursion_limit=max_steps)
        # Need to merge in the existing config with the one that we just created so the notion
        # of "parent_run_id" gets preserved.
        runnable_config = merge_configs(ensure_config(), runnable_config)

        # Attempt to count tokens/costs while invoking the agent.
        token_counter = LangChainTokenCounter(self.primary_llm, self.invocation_context, self.journal, self.origin)
        try:
            # Enter the journaling scope before count_tokens() copies the current context
            # into the agent-chain task. This is what propagates the owning handler to
            # every descendant run while retaining it as the nearest active scope.
            with journaling_callback.scope():
                await token_counter.count_tokens(self.invoke_agent_chain(inputs, runnable_config, max_attempts),
                                                 max_execution_seconds)
        except AsyncTimeout:
            # The token counter already wrote the final AIMessage to the journal
            # (before its token-accounting messages, to preserve message order).
            # Here we only need to surface the timeout in server logs.
            self.logger.warning(
                "Agent '%s' timed out: exceeded max_execution_seconds=%ss and was cancelled.",
                Origination.get_full_name_from_origin(self.origin),
                max_execution_seconds,
            )

        return inputs

    # pylint: disable=too-many-locals,too-many-statements
    async def invoke_agent_chain(self, inputs: Dict[str, Any], runnable_config: Dict[str, Any], max_attempts: int):
        """
        Set the agent in motion

        :param inputs: The inputs to the agent_executor
        :param runnable_config: The runnable_config to send to the agent_executor
        :param max_attempts: The maximum number of attempts to make allowing for errors of any kind.
        """
        chain_result: Union[Dict[str, Any], AgentFinish, AIMessage] = None
        attempts: int = max_attempts
        exception: Exception = None
        backtrace: str = None
        while chain_result is None and attempts > 0:
            # Reset any backtrace from a previous attempt so that whatever is
            # logged after the loop always corresponds to the exception that
            # ended it (not every branch below captures a backtrace).
            backtrace = None
            try:
                chain_result: Dict[str, Any] = await self.agent_chain.ainvoke(input=inputs, config=runnable_config)
            except RATE_LIMIT_ERROR_TYPES as rate_limit_error:
                await self.journal_retry_reason(rate_limit_error, "the LLM provider rate-limited the request")
                attempts = attempts - 1
                exception = rate_limit_error
            except API_ERROR_TYPES as api_error:
                backtrace = traceback.format_exc()
                message: str = None
                if not ApiKeyErrorCheck.check_for_internal_error(backtrace):
                    # Does not look like internal LLM stack error:
                    message = ApiKeyErrorCheck.check_for_api_key_exception(api_error)
                if message is not None:
                    # Construct a uniform message to return to the client
                    # indicating that they likely have an API key problem,
                    # rather than retrying and hitting the same error again.
                    exception = None
                    backtrace = None
                    chain_result = {
                        "output": message
                    }
                    # Log the error with technical details for debugging purposes,
                    # but we are returning a more user-friendly message to the client.
                    # get_safe_log_message() redacts pydantic ValidationError input values
                    # so user-supplied API key material can't leak into server logs.
                    self.logger.error("API KEY error detected: %s",
                                      ApiKeyErrorCheck.get_safe_log_message(api_error))
                    break
                # Continue with regular retry logic:
                await self.journal_retry_reason(api_error, "the LLM API returned an error")
                attempts = attempts - 1
                exception = api_error
            except KeyError as key_error:
                await self.journal_retry_reason(key_error, "the response was missing an expected field")
                attempts = attempts - 1
                exception = key_error
                backtrace = traceback.format_exc()
            except ValueError as value_error:
                response = str(value_error)
                find_string: str = "An output parsing error occurred. " + \
                                   "In order to pass this error back to the agent and have it try again, " + \
                                   "pass `handle_parsing_errors=True` to the AgentExecutor. " + \
                                   "This is the error: Could not parse LLM output: `"
                if response.startswith(find_string):
                    # Agent is returning good stuff, but langchain is erroring out over it.
                    # From: https://github.com/langchain-ai/langchain/issues/1358#issuecomment-1486132587
                    # Per thread consensus, this is hacky and there are better ways to go,
                    # but removes immediate impediments.
                    chain_result = {
                        "output": response.removeprefix(find_string).removesuffix("`")
                    }
                else:
                    await self.journal_retry_reason(value_error, "the model's output could not be parsed")
                    attempts = attempts - 1
                    exception = value_error
                    backtrace = traceback.format_exc()
            # pylint: disable=broad-exception-caught
            except Exception as exception_error:
                # This catches any errors from running middlewares and also error form exceeding the recursion_limit.
                self.sensitive_logger.error("Got exception in  %s. Error: %s", self.__class__.__name__, exception_error)
                # These are likely real issues and non-retryable.
                attempts = 0
                exception = exception_error
                backtrace = traceback.format_exc()

        if chain_result is None and backtrace is not None:
            # Keep the full backtrace in the server logs only. Passing it
            # through as error details would return raw stack traces to clients.
            self.sensitive_logger.error("%s", backtrace)

        output: str = self.parse_chain_result(chain_result, exception)
        return_message: BaseMessage = self.build_return_message(chain_result, output)

        # Chat history is updated in write_message
        await self.journal.write_message(return_message)

    async def journal_retry_reason(self, error: Exception, reason: str):
        """
        Surface the reason for a recoverable-error retry on the journal so clients
        see *why* a step is being retried instead of an unexplained stall. The reason
        is written as an AgentFrameworkMessage: it carries this agent's origin (so it
        is never mistaken for the final answer) and is excluded from chat history (so
        it does not bloat the tokens sent back to the LLM). Backtraces stay in the
        server log only.

        :param error: The recoverable exception triggering the retry.
        :param reason: A concise, client-facing description of what went wrong.
        """
        text: str = f"Retrying: {reason} ({error.__class__.__name__}) - {error}"

        # Log the Exception as a warning, respecting server log sensitivity settings
        self.sensitive_logger.warning(text)

        # Also write the error message to the journal under the same
        # LEAF_LOG_SENSITIVE env var setting as the SensitiveLogger uses.
        if self.sensitive_logger.should_log():
            await self.journal.write_message(AgentFrameworkMessage(content=text))

    @staticmethod
    def find_ai_message(chain_result: Optional[Union[Dict[str, Any], AgentFinish, AIMessage]]) -> Optional[AIMessage]:
        """
        Locate the provider-native AIMessage that carries the chain's answer.

        :param chain_result: The result from invoking the agent chain
                        (see parse_chain_result() for the possible shapes)
        :return: The last AIMessage in a dict result's "messages", the result
                 itself when it is an AIMessage, or None when the result carries
                 no AIMessage at all (exception, API-key error text, bare "output")
        """
        use_result: Any = chain_result
        if isinstance(use_result, AgentFinish):
            # AgentFinish is the return type of langchain's legacy AgentExecutor,
            # which neuro-san stopped using in commit 5c2a0e61. The create_agent
            # graph used today returns a state dict and never an AgentFinish, so
            # this unwrap is kept for backwards compatibility only. Its
            # return_values carry the output in dict form.
            use_result_agent_finish: AgentFinish = use_result
            use_result = use_result_agent_finish.return_values

        if isinstance(use_result, AIMessage):
            # Sometimes we get an AIMessage from a tool call.
            return use_result

        if isinstance(use_result, dict):
            # Normal return value from a chain is a dict.
            # The dict in question usually has chat history in a messages field.
            # We want the last AIMessage from that chat history.
            messages: List[BaseMessage] = use_result.get("messages", [])
            message: BaseMessage = None
            for message in reversed(messages):
                if isinstance(message, AIMessage):
                    return message

        return None

    def parse_chain_result(self, chain_result: Optional[Union[Dict[str, Any], AgentFinish, AIMessage]],
                           exception: Optional[Exception]) -> str:
        """
        Parse the result from the langchain chain.

        :param chain_result: The result from invoking the agent chain.
                        Can be:
                        * An AgentFinish instance whose return_values can be any one of the following
                        * A dictionary whose keys might be:
                            "output" - the actual output to use
                            "messages" - effectively a chat history
                        * An AIMessage whose content is the output to use
                        * None, when every attempt to invoke the chain failed
        :param exception: Any exception that happened along the way,
                        or None if the chain invocation succeeded
        :return: A string value to return as the result of the run.
        """

        # Initialize our output.
        # The value here might morph a bit between types, but when we return
        # something we expect it to be a string.
        output: Optional[Union[str, List[Any]]] = None

        if chain_result is None and exception is not None:
            # We got an exception instead of a proper result. Say so.
            output = f"Agent stopped due to exception {exception}"
        else:
            ai_message: Optional[AIMessage] = self.find_ai_message(chain_result)
            if ai_message is not None:
                # We generally want the content of any single AIMessage we found from above
                output = ai_message.content
            else:
                # We didn't find an AIMessage, so look for a straight-up "output" key:
                # invoke_agent_chain builds {"output": text} on the API-key and
                # output-parse error paths. Unwrap a legacy AgentFinish first (see
                # find_ai_message) so its return_values get the same lookup.
                use_result: Any = chain_result
                if isinstance(use_result, AgentFinish):
                    use_result = use_result.return_values
                if isinstance(use_result, dict):
                    output = use_result.get("output")

        # In general, output is a string, but it can also be a list of content blocks when there are
        # multiple message types, such as "thinking", "reasoning", etc. - or a list of plain strings,
        # which is also legal per the BaseMessage annotation.
        # Project list output to its full text through the single projection policy ContentUtils
        # defines: OriginatingJournal's dupe suppression relies on the AGENT and AI copies of the
        # same output projecting to the same text. Full text also means the error detector below
        # scans everything, exactly as it always has for plain-string output.
        # For more details: https://docs.langchain.com/oss/python/langchain/messages#standard-content-blocks
        if isinstance(output, list):
            output_list: List[Any] = output
            output = ContentUtils.flatten_to_text(output_list)

        # See if we had some kind of error and format accordingly, if asked for.
        handled_output: str = self.error_detector.handle_error(output)
        return handled_output

    def build_return_message(self, chain_result: Optional[Union[Dict[str, Any], AgentFinish, AIMessage]],
                             output: str) -> BaseMessage:
        """
        Build the AIMessage that is journaled as this agent's answer for the turn.

        Plain-string answers, error paths, and anything the ErrorDetector
        rewrote keep the exact shape they have always had: a fresh AIMessage
        carrying only the parsed text. When the provider-native message
        carries block content (Anthropic thinking, OpenAI Responses reasoning,
        ...), that message is preserved instead, with its content normalized
        to standard v1 blocks (see ContentUtils.normalize_message) so the
        blocks and its usage_metadata reach the journal. The wire carries
        the same text either way; for preserved block content the converter
        also emits the content_blocks wrapper.

        The chat history does not depend on which shape is chosen:
        OriginatingJournal.write_message appends a text-only copy of any
        block-content AI message, so what is handed to a provider (or a
        fallback provider) stays provider-agnostic.

        :param chain_result: The result from invoking the agent chain
        :param output: The parsed, error-checked text from parse_chain_result()
        :return: The BaseMessage to journal as the answer
        """
        ai_message: Optional[AIMessage] = self.find_ai_message(chain_result)
        if ai_message is None:
            # Exception, API-key error text or a bare "output": nothing native to preserve.
            return AIMessage(output)

        if output != ContentUtils.flatten_to_text(ai_message):
            # The ErrorDetector rewrote the text. The client-visible answer is
            # the formatted error, not the native content.
            return AIMessage(output)

        if isinstance(ai_message, AIMessageChunk):
            # normalize_message is for complete messages only: chunk-only
            # shapes are not content. Chains return complete messages today,
            # but a custom middleware could hand back a chunk, and preserving
            # its class would give the journaled answer an unknown wire type.
            ai_message = message_chunk_to_message(ai_message)

        preserved: BaseMessage = ContentUtils.normalize_message(ai_message)
        if isinstance(preserved.content, str):
            # Trivial (text-only) content: keep the exact message shape that has
            # always been journaled for it. Preserving the native object would
            # change nothing a client can see and would only drag provider
            # bookkeeping (ids, metadata) along with it.
            return AIMessage(output)

        if ContentUtils.flatten_to_text(preserved) != output:
            # Fail closed. The provider translators behind normalize_message
            # skip content items they do not recognize (e.g. a bare string
            # inside a block list), which can drop text. The client-visible
            # answer must stay the parsed text, so blocks are preserved only
            # while they still project to it.
            return AIMessage(output)

        # What reaches this point with the pinned providers: an Anthropic
        # answer with extended thinking on (thinking blocks, then text;
        # normalized to reasoning + text with the signature kept in extras,
        # while a redacted_thinking block stays a non_standard wrapper around
        # its opaque data, see LangchainV1ContentBlocksFormat.blocks_of), an OpenAI
        # Responses answer with reasoning summaries on (reasoning items, then
        # text, with their ids kept on the blocks), or any answer whose text
        # arrives as two or more text blocks or as a text block carrying a
        # key with a value beyond type/text/id/index (annotations, extras, an
        # OpenAI Responses "phase"), since the format's is_trivial collapses only a single
        # plain text block. Not expected here: tool-call blocks
        # (blocks_of leaves them out), data blocks (providers do not
        # emit them in assistant answers), chunks (converted above) and mixed
        # string-and-block lists (caught by the text check above).
        return preserved
