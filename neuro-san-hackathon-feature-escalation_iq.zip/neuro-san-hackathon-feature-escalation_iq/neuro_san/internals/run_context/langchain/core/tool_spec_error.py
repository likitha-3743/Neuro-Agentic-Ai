
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT


class ToolSpecError(ValueError):
    """
    Raised when a tool's function spec (an OpenAI-function-style dictionary)
    cannot be converted into a working tool - for example an unrecognized
    parameter type string or a parameter name that pydantic cannot accept
    as a field name.

    Subclasses ValueError so that existing broad handlers and the network
    validators keep catching it, while callers that need to distinguish
    "the spec is bad" from other ValueErrors (like the connectivity errors
    reported by external agent adapters) can catch this type specifically.
    """
