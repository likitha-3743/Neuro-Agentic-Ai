
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Any
from typing import Dict
from typing import Type

from langchain_core.language_models.base import BaseLanguageModel

from neuro_san.internals.run_context.langchain.llms.llm_policy import LlmPolicy


class NvidiaLlmPolicy(LlmPolicy):
    """
    LlmPolicy implementation for Nvidia.

    Nvidia does not allow for passing in async web clients.
    As a matter of fact, all of its clients are synchronous,
    and use request.Sessions which only last as long as a single call to their client.
    This is not the best arrangement for an async service.
    """

    def create_llm(self, config: Dict[str, Any], model_name: str, client: Any) -> BaseLanguageModel:
        """
        Create a BaseLanguageModel instance from the fully-specified llm config
        for the llm class that the implementation supports.  Chat models are usually
        per-provider, where the specific model itself is an argument to its constructor.

        :param config: The fully specified llm config
        :param model_name: The name of the model
        :param client: The web client to use (if any)
        :return: A BaseLanguageModel (can be Chat or LLM)
        """

        # Use lazy loading to prevent installing the world
        # pylint: disable=invalid-name
        ChatNVIDIA: Type[BaseLanguageModel] = self.resolver.resolve_class_in_module(
            "ChatNVIDIA",
            module_name="langchain_nvidia_ai_endpoints",
            install_if_missing="langchain-nvidia-ai-endpoints")
        # Higher temperature is more random
        llm: BaseLanguageModel = ChatNVIDIA(
            base_url=config.get("base_url"),
            model=model_name,
            temperature=config.get("temperature"),
            max_tokens=config.get("max_tokens"),
            top_p=config.get("top_p"),
            seed=config.get("seed"),
            stop=config.get("stop"),

            # If omitted, this defaults to the global verbose value,
            # accessible via langchain_core.globals.get_verbose():
            # https://github.com/langchain-ai/langchain/blob/master/libs/core/langchain_core/globals.py#L53
            #
            # However, accessing the global verbose value during concurrent initialization
            # can trigger the following warning:
            #
            # UserWarning: Importing verbose from langchain root module is no longer supported.
            # Please use langchain.globals.set_verbose() / langchain.globals.get_verbose() instead.
            # old_verbose = langchain.verbose
            #
            # To prevent this, we explicitly set verbose=False here (which matches the default
            # global verbose value) so that the warning is never triggered.
            verbose=False,
            nvidia_api_key=self.get_value_or_env(config, "nvidia_api_key",
                                                 "NVIDIA_API_KEY"),
            nvidia_base_url=self.get_value_or_env(config, "nvidia_base_url",
                                                  "NVIDIA_BASE_URL"),
        )
        return llm

    async def delete_resources(self):
        """
        Release the run-time resources used by the model
        """
        if self.llm is None:
            return

        # Let's not do this again, shall we?
        self.llm = None
