
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
from typing import Any
from typing import Dict
from typing import Type

from contextlib import suppress
from httpx import AsyncClient
from httpx import Limits

from langchain_core.language_models.base import BaseLanguageModel

from leaf_common.config.config_util import ConfigUtil

from neuro_san.internals.run_context.langchain.llms.llm_policy import LlmPolicy


class OpenAILlmPolicy(LlmPolicy):
    """
    LlmPolicy implementation for OpenAI.

    OpenAI's BaseLanguageModel implementations do allow us to pass in a web client
    as an argument, so this implementation takes advantage of the create_client()
    method to do that. Worth noting that where many other implementations might care about
    the llm reference, because of our create_client() implementation, we do not.

    The chat model built is ToolStrictChatOpenAI, a ChatOpenAI subclass that adds the
    "tool_strict" default for function tools; see resolve_chat_model_class().
    """

    # None means no limit
    LIMITS: Limits = Limits(max_connections=None, max_keepalive_connections=None)

    def __init__(self, llm: BaseLanguageModel = None):
        """
        Constructor.
        """
        super().__init__()

        self.http_client: AsyncClient = None

        # Not doing lazy type resolution here just for type hints.
        # Save that for create_client(), where it's meatier.
        self.async_openai_client: Any = None

    def create_client(self, config: Dict[str, Any]) -> Any:
        """
        Creates the web client to used by a BaseLanguageModel to be
        constructed in the future.  Neuro SAN infrastructures prefers that this
        be an asynchronous client, however we realize some BaseLanguageModels
        do not support that (even though they should!).

        Implementations should retain any references to state that needs to be cleaned up
        in the delete_resources() method.

        :param config: The fully specified llm config
        :return: The web client that accesses the LLM.
                By default this is None, as many BaseLanguageModels
                do not allow a web client to be passed in as an arg.
        """
        # OpenAI is the one chat class that we do not require any extra installs.
        # This is what we want to work out of the box.
        # Nevertheless, have it go through the same lazy-loading resolver rigamarole as the others.

        # pylint: disable=invalid-name
        AsyncOpenAI: Type[Any] = self.resolver.resolve_class_in_module(
            "AsyncOpenAI",
            module_name="openai",
            install_if_missing="langchain-openai")

        self.create_http_client(config)

        self.async_openai_client = AsyncOpenAI(
            api_key=self.get_value_or_env(config, "openai_api_key", "OPENAI_API_KEY"),
            base_url=self.get_value_or_env(config, "openai_api_base", "OPENAI_API_BASE"),
            organization=self.get_value_or_env(config, "openai_organization", "OPENAI_ORG_ID"),
            timeout=config.get("request_timeout"),
            max_retries=config.get("max_retries"),
            http_client=self.http_client
        )

        # We retain the async_openai_client reference, but we hand back this reach-in
        # to pass to the BaseLanguageModel constructor.
        return self.async_openai_client.chat.completions

    def create_http_client(self, config: Dict[str, Any]):
        """
        Creates the http client from the given config.

        :param config: The fully specified llm config
        """
        # Our run-time model resource here is httpx client which we need to control directly:
        openai_proxy: str = self.get_value_or_env(config, "openai_proxy", "OPENAI_PROXY")
        request_timeout: int = config.get("request_timeout")
        self.http_client = AsyncClient(proxy=openai_proxy, timeout=request_timeout, limits=OpenAILlmPolicy.LIMITS)

    def create_llm(self, config: Dict[str, Any], model_name: str, client: Any) -> BaseLanguageModel:
        """
        Create a BaseLanguageModel instance from the fully-specified llm config
        for the llm class that the implementation supports.  Chat models are usually
        per-provider, where the specific model itself is an argument to its constructor.

        :param config: The fully specified llm config
        :param model_name: The name of the model
        :param client: The web client to use (if any)
        :return: A BaseLanguageModel (can be Chat or LLM)
        """
        # OpenAI is the one chat class that we do not require any extra installs.
        # This is what we want to work out of the box.
        # Even so, the chat model class is loaded through the same lazy resolver as the other providers,
        # so that the openai packages stay optional for installs that only use other providers.
        chat_model_class: Type[BaseLanguageModel] = self.resolve_chat_model_class()

        # Now construct LLM chat model we will be using:
        llm: BaseLanguageModel = chat_model_class(
            async_client=client,
            root_async_client=self.async_openai_client,
            model_name=model_name,
            temperature=config.get("temperature"),

            # This next group of params should always be None when we have async_client
            openai_api_key=self.get_value_or_env(config, "openai_api_key",
                                                 "OPENAI_API_KEY", client),
            openai_api_base=self.get_value_or_env(config, "openai_api_base",
                                                  "OPENAI_API_BASE", client),
            openai_organization=self.get_value_or_env(config, "openai_organization",
                                                      "OPENAI_ORG_ID", client),
            openai_proxy=self.get_value_or_env(config, "openai_proxy",
                                               "OPENAI_PROXY", client),
            request_timeout=self.get_value_or_env(config, "request_timeout", None, client),
            max_retries=self.get_value_or_env(config, "max_retries", None, client),

            presence_penalty=config.get("presence_penalty"),
            frequency_penalty=config.get("frequency_penalty"),
            seed=config.get("seed"),
            logprobs=config.get("logprobs"),
            top_logprobs=config.get("top_logprobs"),
            logit_bias=config.get("logit_bias"),
            # Streaming is configurable via the "streaming" key in llm_config; defaults
            # to False so existing agents keep their long-standing non-streaming behavior.
            # We pass streaming explicitly (rather than relying on LangChain's default) so
            # that langchain_core._should_stream() picks up the configured value even when
            # a streaming-aware callback handler is attached to the run manager. Token
            # usage is collected from AIMessage.usage_metadata in LlmTokenCallbackHandler
            # regardless of streaming mode.
            streaming=ConfigUtil.get_bool(config, "streaming"),
            # n is intentionally not sent. Chat Completions defaults n to 1, which is all neuro-san
            # ever consumes, and the Responses API has no n parameter at all. langchain-openai
            # forwards n whenever it is not None, so an explicit n=1 made every request that
            # reached the Responses API fail client-side.
            # See https://github.com/cognizant-ai-lab/neuro-san/issues/725 and the n property of
            # CreateChatCompletionRequest in https://github.com/openai/openai-openapi/blob/main/openapi.yaml
            top_p=config.get("top_p"),
            max_tokens=config.get("max_tokens"),  # This is always for output
            tiktoken_model_name=config.get("tiktoken_model_name"),
            # Only takes effect on Chat Completions: langchain-openai drops stop from Responses API
            # requests (the API has no such parameter) rather than failing.
            stop=config.get("stop"),

            # The following three parameters are for reasoning models only.
            # Set either "reasoning" or "reasoning_effort", not both: on the Responses API path
            # langchain-openai folds reasoning_effort into reasoning["effort"] only when
            # "reasoning" is absent, so a "reasoning" dict silently wins over reasoning_effort.
            reasoning=config.get("reasoning"),
            reasoning_effort=config.get("reasoning_effort"),
            verbosity=config.get("verbosity"),

            # use_responses_api is a tri-state switch for which OpenAI endpoint ChatOpenAI uses.
            # https://reference.langchain.com/python/langchain-openai/chat_models/base/BaseChatOpenAI/use_responses_api
            # https://docs.langchain.com/oss/python/integrations/chat/openai#responses-api
            #   True  - the class default in default_llm_info.hocon: every OpenAI model goes to the
            #           Responses API. Tool calling with reasoning on the newest models needs this,
            #           because Chat Completions rejects function tools combined with reasoning.
            #           gpt-6-astra has no other option: Chat Completions has no function calling for it
            #           and it rejects reasoning_effort "none". gpt-5.6-* would otherwise need
            #           reasoning_effort "none" to call tools at all.
            #           https://developers.openai.com/api/docs/guides/reasoning
            #           https://developers.openai.com/api/docs/guides/migrate-to-responses
            #   False - force Chat Completions. Needed for OpenAI-compatible gateways that only
            #           implement /chat/completions. For gpt-5.6-* combine it with reasoning_effort
            #           "none" so tool calls still work (without reasoning).
            #   None  - let langchain-openai infer the endpoint from the other parameters and the
            #           model name: any Responses-only setting (reasoning, include, truncation,
            #           context_management, previous_response_id, text, built-in tools) or a
            #           Responses-only model (gpt-5.x-pro, codex) selects the Responses API, otherwise
            #           Chat Completions. This was the class default before the Responses API became
            #           the default endpoint.
            # This is deliberately forwarded raw instead of through ConfigUtil.get_bool():
            # get_bool() turns an absent/null value into False. An explicit false must reach langchain
            # as False (pin Chat Completions), and a null must reach it as None so that inference still
            # works for users who opt back into it; a null collapsed to False would send a "reasoning"
            # dict to Chat Completions and pin the *-pro models to an endpoint OpenAI rejects.
            use_responses_api=config.get("use_responses_api"),

            # store controls whether OpenAI keeps the response server-side. OpenAI stores by default
            # (for 30 days); the class default in default_llm_info.hocon is false, which keeps every
            # request stateless. Reasoning replay in the tool-calling loop still works statelessly,
            # because the Responses API includes encrypted_content on reasoning items by default and
            # langchain-openai replays any reasoning item that carries it. Chat Completions accepts
            # store as well, so forwarding it is safe on either endpoint. Forwarded raw for the same
            # reason as use_responses_api: a null must reach langchain as None so the field is left
            # out of the request entirely (some gateways reject fields they do not know).
            # https://developers.openai.com/api/docs/guides/reasoning
            # https://docs.langchain.com/oss/python/integrations/chat/openai#responses-api
            store=config.get("store"),

            # include is the list of extra output fields to return, e.g. ["reasoning.encrypted_content"].
            # OpenAI still accepts that legacy value but no longer requires it, because encrypted_content
            # is included by default. Any non-None include is a Responses API routing trigger in
            # langchain-openai, and the Chat Completions SDK call rejects the keyword outright, so it is
            # forwarded raw and must never be given a non-null class default.
            # https://developers.openai.com/api/docs/guides/reasoning
            # https://reference.langchain.com/python/langchain-openai/chat_models/base/BaseChatOpenAI/use_responses_api
            include=config.get("include"),

            # tool_strict is the default strict value for function tools (bool or null). The class
            # default in default_llm_info.hocon is false, and false is the fallback here too when the
            # key is absent. It is not a ChatOpenAI constructor argument: ToolStrictChatOpenAI applies
            # it in bind_tools(), which is where langchain writes strict into each tool and which
            # create_agent() calls without a strict value. An explicit null still reaches the chat
            # model as None (send no strict, the endpoint decides), unlike false (send "strict": false).
            tool_strict=config.get("tool_strict", False),

            # If omitted, this defaults to the global verbose value,
            # accessible via langchain_core.globals.get_verbose():
            # https://github.com/langchain-ai/langchain/blob/master/libs/core/langchain_core/globals.py#L53
            #
            # However, accessing the global verbose value during concurrent initialization
            # can trigger the following warning:
            #
            # UserWarning: Importing verbose from langchain root module is no longer supported.
            # Please use langchain.globals.set_verbose() / langchain.globals.get_verbose() instead.
            # old_verbose = langchain.verbose
            #
            # To prevent this, we explicitly set verbose=False here (which matches the default
            # global verbose value) so that the warning is never triggered.
            verbose=False,

            # Track streaming: emit token-usage frames only when streaming is enabled.
            stream_usage=ConfigUtil.get_bool(config, "streaming")
        )

        return llm

    def resolve_chat_model_class(self) -> Type[BaseLanguageModel]:
        """
        Resolves the chat model class this policy and its subclasses construct.

        That is ToolStrictChatOpenAI, the ChatOpenAI subclass with the "tool_strict" default for
        function tools. It is resolved by name at call time rather than imported at module level,
        so that importing this policy does not import langchain-openai and the openai packages stay
        optional for installs that only use other providers.

        :return: The ToolStrictChatOpenAI class
        """
        # Resolving ChatOpenAI first keeps the helpful error: when langchain-openai is missing, the
        # Resolver then names the package to pip install instead of blaming the subclass module.
        self.resolver.resolve_class_in_module("ChatOpenAI",
                                              module_name="langchain_openai.chat_models.base",
                                              install_if_missing="langchain-openai")

        chat_model_class: Type[BaseLanguageModel] = self.resolver.resolve_class_in_module(
            "ToolStrictChatOpenAI",
            module_name="neuro_san.internals.run_context.langchain.llms.tool_strict_chat_openai")
        return chat_model_class

    async def delete_resources(self):
        """
        Release the run-time resources used by the instance.
        """
        self.async_openai_client = None

        if self.http_client is not None:
            with suppress(Exception):
                await self.http_client.aclose()

        self.http_client = None
