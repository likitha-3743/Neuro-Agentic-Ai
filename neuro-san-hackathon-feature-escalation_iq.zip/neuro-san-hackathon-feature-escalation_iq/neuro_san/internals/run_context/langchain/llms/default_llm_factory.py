
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Set
from typing import Type
from typing import Tuple

from copy import copy as shallow_copy
from logging import Logger
from logging import getLogger
from random import shuffle

import os

from langchain_core.language_models.base import BaseLanguageModel

from leaf_common.config.dictionary_overlay import DictionaryOverlay
from leaf_common.parsers.dictionary_extractor import DictionaryExtractor
from leaf_common.resolution.resolver_util import ResolverUtil

from neuro_san.internals.interfaces.context_type_llm_factory import ContextTypeLlmFactory
from neuro_san.internals.interfaces.environment_configuration import EnvironmentConfiguration
from neuro_san.internals.run_context.langchain.llms.langchain_llm_factory import LangChainLlmFactory
from neuro_san.internals.run_context.langchain.llms.langchain_llm_resources import LangChainLlmResources
from neuro_san.internals.run_context.langchain.llms.llm_info_restorer import LlmInfoRestorer
from neuro_san.internals.run_context.langchain.llms.standard_langchain_llm_factory import StandardLangChainLlmFactory
from neuro_san.internals.run_context.langchain.util.api_key_error_check import ApiKeyErrorCheck
from neuro_san.internals.run_context.langchain.util.argument_validator import ArgumentValidator

KEYS_TO_REMOVE_FOR_USER_CLASS: Set[str] = {"class", "provider_tools", "verbose"}

# Lazily import specific errors from llm providers
API_KEY_ERRORS: Tuple[Type[Any], ...] = ResolverUtil.create_type_tuple([
                                            "google.auth.exceptions.DefaultCredentialsError",
                                            "openai.OpenAIError",
                                            "pydantic_core.ValidationError",
                                        ])


class DefaultLlmFactory(EnvironmentConfiguration, ContextTypeLlmFactory, LangChainLlmFactory):
    """
    Factory class for LLM operations

    Most methods take a config dictionary which consists of the following keys:

        "model_name"                The name of the model.
                                    Default if not specified is "gpt-3.5-turbo"

        "temperature"               A float "temperature" value with which to
                                    initialize the chat model.  In general,
                                    higher temperatures yield more random results.
                                    Default if not specified is the provider's default.

        "prompt_token_fraction"     The fraction of total tokens (not necessarily words
                                    or letters) to use for a prompt. Each model_name
                                    has a documented number of max_tokens it can handle
                                    which is a total count of message + response tokens
                                    which goes into the calculation involved in
                                    get_max_prompt_tokens().
                                    By default the value is 0.5.

        "max_tokens"                The maximum number of tokens to use in
                                    get_max_prompt_tokens(). By default this comes from
                                    the model description in this class.
    """

    def __init__(self, config: Dict[str, Any] = None):
        """
        Constructor

        :param config: The config dictionary which may or may not contain
                       keys for the context_type and agent_llm_info_file
        """
        self.logger: Logger = getLogger(self.__class__.__name__)
        self.llm_infos: Dict[str, Any] = {}
        self.overlayer = DictionaryOverlay()
        self.llm_factories: List[LangChainLlmFactory] = [
            StandardLangChainLlmFactory()
        ]

        # Get user LLM info file path with the following priority:
        # 1. "llm_info_file" from agent network hocon
        # 2. "AGENT_LLM_INFO_FILE" from environment variable
        raw_llm_info_file: str = None
        if config:
            raw_llm_info_file: str = (
                config.get("llm_info_file")
                or os.getenv("AGENT_LLM_INFO_FILE")
            )
        else:
            raw_llm_info_file = os.getenv("AGENT_LLM_INFO_FILE")

        if raw_llm_info_file is not None and not isinstance(raw_llm_info_file, str):
            raise TypeError(
                "The values of 'llm_info_file' and "
                "the 'AGENT_LLM_INFO_FILE' environment variable must be strings. "
                f"Got {type(raw_llm_info_file).__name__} instead."
            )

        self.llm_info_file: str = raw_llm_info_file

    def load(self):
        """
        Loads the LLM information from hocon files.
        """
        restorer = LlmInfoRestorer()
        self.llm_infos = restorer.restore()

        # Mix in user-specified llm info, if available.
        if self.llm_info_file:
            extra_llm_infos: Dict[str, Any] = restorer.restore(file_reference=self.llm_info_file)
            # Each user entry DEEP-MERGES with any same-named default entry, so a
            # sparse override like {"gpt-4.1": {"class": "x"}} inherits the default
            # entry's remaining fields (including a "use_model_name" alias redirect).
            # This holds for .json user files too now that keys are sanitized at
            # parse time: their dotted model names ("llama3.1") match the default
            # keys. Before sanitization, such keys missed the quoted default keys
            # ('"llama3.1"') and accidentally replaced the default entry wholesale.
            self.llm_infos = self.overlayer.overlay(self.llm_infos, extra_llm_infos)

        # Resolve any new llm factories
        extractor = DictionaryExtractor(self.llm_infos)
        llm_factory_classes: List[str] = []
        llm_factory_classes = extractor.get("classes.factories", llm_factory_classes)
        if not isinstance(llm_factory_classes, List):
            raise ValueError(f"The classes.factories key in {self.llm_info_file} must be a list of strings")

        llm_factory_class_name: str = None
        for llm_factory_class_name in llm_factory_classes:
            llm_factory: LangChainLlmFactory = self.resolve_one_llm_factory(llm_factory_class_name, self.llm_info_file)
            # Success. Tack it on to the list
            self.llm_factories.append(llm_factory)

        # DEF - Might also want client factory extension eventually

    def resolve_one_llm_factory(self, llm_factory_class_name: str, llm_info_file: str) -> LangChainLlmFactory:
        """
        :param llm_factory_class_name: A single class name to resolve.
        :param llm_info_file: The name of the hocon file with the class names, to reference
                        when exceptions are thrown.
        :return: A LangChainLlmFactory instance as per the input
        """
        if not isinstance(llm_factory_class_name, str):
            raise ValueError(f"The value for the classes.factories key in {llm_info_file} "
                             "must be a list of strings")

        # Resolve and instantiate the factory class
        llm_factory: LangChainLlmFactory = ResolverUtil.create_instance(
            class_name=llm_factory_class_name,
            class_name_source=llm_info_file,
            type_of_class=LangChainLlmFactory
        )

        return llm_factory

    def create_llm(self, config: Dict[str, Any], sly_data: Dict[str, Any] = None) -> LangChainLlmResources | Set[str]:
        """
        Creates a langchain LLM based on the 'model_name' value of
        the config passed in.

        :param config: A dictionary which describes which LLM to use.
                See the class comment for details.
        :param sly_data: A user-provided dictionary of private data,
                from which we might extract API keys to use for user billing.
                Can be None indicating no API keys are provided at all and the system defaults will be used.
        :return: A LangChainLlmResources instance containing
                a BaseLanguageModel (can be Chat or LLM) and all related resources
                necessary for managing the model run-time lifecycle.
                Can also return a set of strings describing any required sly_data API keys that are not provided.
                Can raise a ValueError if the config's class or model_name value is
                unknown to this method.
        """
        full_config: Dict[str, Any] | Set[str] = self.create_full_llm_config(config, sly_data)
        if full_config is None or isinstance(full_config, set):
            return full_config

        llm_resources: LangChainLlmResources = self.create_llm_resources(full_config)
        return llm_resources

    def create_full_llm_config(self, config: Dict[str, Any], sly_data: Dict[str, Any]) -> Dict[str, Any] | Set[str]:
        """
        :param config: The llm_config from the user
        :param sly_data: A user-provided dictionary of private data,
                from which we might extract API keys to use for user billing.
                Can be None indicating no API keys are provided at all and the system defaults will be used.
        :return: The fully specified config with defaults filled in.
                Can also return a set of strings describing any required sly_data API keys that are not provided.
        """
        full_config: Dict[str, Any] | Set[str] = None

        class_from_llm_config: str = config.get("class")
        if class_from_llm_config:

            if not isinstance(class_from_llm_config, str):
                raise ValueError("Value of 'class' has to be string.")

            # A "class" key in the config indicates the user has specified a particular LLM implementation.
            # However, the config may only contain partial arguments (e.g., {"arg_1": 0.5}) and omit others.
            #
            # In the standard factory, LLM classes are instantiated like:
            #   ChatOpenAI(arg_1=config.get("arg_1"), arg_2=config.get("arg_2"))
            # If a required argument like "arg_2" is missing in the config, config.get("arg_2") returns None,
            # which may raise an error during instantiation if the argument has no default.
            #
            # To prevent this, we first fetch the default arguments for the given class from llm_info,
            # then merge them with the user-provided config. This ensures all expected arguments are present,
            # and the user’s config values take precedence over the defaults.
            config_from_class_in_llm_info: Dict[str, Any] = self.get_chat_class_args(class_from_llm_config)

            # Merge the defaults from llm_info with the user-defined config,
            # giving priority to values in config.
            full_config = self.overlayer.overlay(config_from_class_in_llm_info, config)

            # Users do not always know whether a model_name is one of our aliases
            # (e.g. "claude-opus") or a real provider model id, so for our own classes
            # follow any alias to the model id the provider actually accepts.
            # See https://github.com/cognizant-ai-lab/neuro-san/issues/1298
            #
            # Full langchain class paths are deliberately left alone: with those the user
            # brings both the model and its arguments and nothing from llm_info applies.
            #
            # This has to happen before replace_any_required_api_keys(), which can turn
            # full_config into a set of missing sly_data keys that cannot be indexed.
            if self.is_llm_info_class(class_from_llm_config):
                alias_model_name: Any = full_config.get("model_name")
                # Only strings can be looked up. A missing model_name is legitimate for
                # some classes (e.g. azure-openai selects the model by deployment_name).
                if isinstance(alias_model_name, str):
                    full_config["model_name"] = self.resolve_model_name_alias(alias_model_name)

            # Get any required api keys into the full config.
            full_config = self.replace_any_required_api_keys(full_config, sly_data)
            return full_config

        default_config: Dict[str, Any] = self.llm_infos.get("default_config")
        use_config: Dict[str, Any] = self.overlayer.overlay(default_config, config)

        model_name: str = use_config.get("model_name")

        # Follow any alias to the entry that carries the class and model details.
        resolved: Tuple[Dict[str, Any], str] = self._resolve_llm_entry(model_name)
        llm_entry: Dict[str, Any] = resolved[0]
        use_model_name: str = resolved[1]

        # Take a look at the chat classes.
        chat_class_name: str = llm_entry.get("class")
        if chat_class_name is None:
            raise ValueError(f"llm info entry for {use_model_name} requires a 'class' key/value pair.")

        # Get defaults for the chat class
        chat_args: Dict[str, Any] = self.get_chat_class_args(chat_class_name, use_model_name)

        # Get a new sense of the default config now that we have the default args for the chat class.
        default_config = self.overlayer.overlay(chat_args, default_config)

        # Now that we have the true defaults, overlay the config that came in to get the
        # config we are going to use.
        full_config = self.overlayer.overlay(default_config, config)
        full_config["class"] = chat_class_name
        full_config["model_name"] = llm_entry.get("use_model_name", use_model_name)

        # Get any required api keys into the full config.
        full_config = self.replace_any_required_api_keys(full_config, sly_data)
        if full_config is not None and not isinstance(full_config, set):
            # Attempt to get a max_tokens through calculation
            full_config["max_tokens"] = self.get_max_prompt_tokens(full_config)

        return full_config

    def is_llm_info_class(self, chat_class_name: str) -> bool:
        """
        Tells whether a "class" value from an llm_config names one of the classes in the
        llm_info "classes" table (stock ones like "openai" or "anthropic", or ones a user
        added through their own llm_info_file), as opposed to the full python path of a
        langchain chat model class.

        :param chat_class_name: The value of the "class" key from an llm_config
        :return: True if the class is defined in the llm_info "classes" table
        """
        chat_classes: Dict[str, Any] = self.llm_infos.get("classes", {})
        return chat_class_name in chat_classes

    def _find_llm_entry(self, model_name: str) -> Tuple[Optional[Dict[str, Any]], str]:
        """
        Looks up the llm_info entry for a model name, following at most one alias hop.

        An alias is an entry with at most two keys whose "use_model_name" points at the
        real entry (e.g. "claude-fable" -> "claude-fable-5-1"). Entries with more keys
        keep their own details even when they carry a "use_model_name" of their own
        (e.g. the azure-* entries, whose "class" must win over their target's).
        This method never raises; callers decide how to treat a missing entry.

        :param model_name: The model name from the config
        :return: A tuple of (llm_entry, use_model_name). llm_entry is the entry after any
                alias hop, or None when either model_name or the alias target has no entry.
                use_model_name is the name the alias pointed at, or model_name itself when
                there was no alias.
        """
        llm_entry: Dict[str, Any] = self.llm_infos.get(model_name)
        if llm_entry is None:
            return None, model_name

        use_model_name: str = llm_entry.get("use_model_name", model_name)
        # The two-key limit is what lets a sparse user overlay such as
        # {"claude-fable": {"model_info_url": ...}} keep behaving as an alias.
        is_alias: bool = len(llm_entry.keys()) <= 2 and use_model_name is not None
        resolved_entry: Dict[str, Any] = llm_entry
        if is_alias:
            resolved_entry = self.llm_infos.get(use_model_name)
        return resolved_entry, use_model_name

    def _resolve_llm_entry(self, model_name: str) -> Tuple[Dict[str, Any], str]:
        """
        Looks up the llm_info entry for a model name, following at most one alias hop,
        and insists that an entry exists.

        :param model_name: The model name from the config
        :return: A tuple of (llm_entry, use_model_name) as described in _find_llm_entry(),
                with llm_entry guaranteed not to be None.
        :raises ValueError: if there is no entry for model_name, or for the alias target
        """
        if self.llm_infos.get(model_name) is None:
            raise ValueError(f"No llm entry for model_name {model_name}")

        found: Tuple[Optional[Dict[str, Any]], str] = self._find_llm_entry(model_name)
        llm_entry: Dict[str, Any] = found[0]
        use_model_name: str = found[1]
        if llm_entry is None:
            raise ValueError(f"No llm entry for use_model_name {use_model_name} in {model_name}")

        return llm_entry, use_model_name

    def resolve_model_name_alias(self, model_name: str) -> str:
        """
        Turns a model name that might be an llm_info alias into the model id the provider
        accepts, without requiring the name to be known to llm_info at all.

        This serves llm_configs that name one of our classes explicitly: the model may be one
        we know (possibly under an alias) or one we have never heard of, and either way the
        user's class is what gets instantiated.

        :param model_name: The model name from the config
        :return: The resolved model id, or model_name unchanged when llm_info does not know it.
                When an alias points at a name that has no entry of its own, that name is
                returned as-is so the provider can be the judge of it.
        """
        found: Tuple[Optional[Dict[str, Any]], str] = self._find_llm_entry(model_name)
        llm_entry: Dict[str, Any] = found[0]
        use_model_name: str = found[1]
        if llm_entry is None:
            # Either an unknown model (use_model_name == model_name) or a dangling alias target.
            return use_model_name

        # Full entries can carry a "use_model_name" of their own (e.g. azure-gpt-4o -> gpt-4o-2024-08-06).
        # This mirrors how create_full_llm_config() fills in model_name when no class is given.
        resolved: str = llm_entry.get("use_model_name", use_model_name)
        return resolved

    def get_chat_class_args(self, chat_class_name: str, use_model_name: str = None) -> Dict[str, Any]:
        """
        :param chat_class_name: string name of the chat class to look up.
        :param use_model_name: the original model name that prompted the chat class lookups
        :return: A dictionary of default arguments for the chat class.
                Can throw an exception if the chat class does not exist.
        """

        # Find the chat class.
        chat_classes: Dict[str, Any] = self.llm_infos.get("classes")
        chat_class: Dict[str, Any] = chat_classes.get(chat_class_name)
        if chat_class is None:
            if use_model_name is not None:
                # If use_model_name is given, it must have a "class" in "classes"
                raise ValueError(f"llm info entry for {use_model_name} uses a 'class' of {chat_class_name} "
                                 "which is not defined in the 'classes' table.")
            # If use_model_name is not provided and chat_class_name is not in "classes" in llm_info,
            # it could be a user-specified langchain model class
            return {}

        # Get the args from the chat class
        args: Dict[str, Any] = chat_class.get("args")

        extends: str = chat_class.get("extends")
        if extends is not None:
            # If this class extends another, get its args too.
            # The overlay wins, so this class's own args override the inherited ones.
            extends_args: Dict[str, Any] = self.get_chat_class_args(extends, use_model_name)
            args = self.overlayer.overlay(extends_args, args)

        return args

    def replace_any_required_api_keys(
                self,
                config: Dict[str, Any],
                sly_data: Dict[str, Any]
            ) -> Dict[str, Any] | Set[str]:
        """
        Get any required api keys into the config.
        :param config: The fully specified llm config which is a product of
                    _create_full_llm_config() above.
        :param sly_data: A user-provided dictionary of private data,
                from which we might extract API keys to use for user billing.
                Can be None indicating no API keys are provided at all and the system defaults will be used.
        :return: The config with any required api keys replaced, or a set of missing
            required config field names if any required api keys were not provided.
        """
        use_api_keys: Dict[str, str] = {}
        if sly_data is not None and isinstance(sly_data, dict):
            use_api_keys = sly_data.get("llm_config", use_api_keys)

        # Loop through each of the config values and replace any "sly_data" values
        # with their corresponding values from the llm_config dictionary.
        required_set: Set[str] = set()
        key: str = None
        value: Any = None
        for key, value in config.items():
            # If any value is "sly_data", replace it with the same value from the llm_config dictionary
            small_value: str = str(value).lower()
            if small_value == "sly_data":
                # If we have a value in the sly_data.llm_config dictionary, use it,
                new_value: Any = use_api_keys.get(key)
                if new_value is not None:
                    if isinstance(new_value, str):
                        # Remove leading and trailing whitespace because often these values
                        # are going into http headers which don't like the extra whitespace.
                        new_value = new_value.strip()
                    config[key] = new_value
                else:
                    # Add to the list of complaints about what is missing.
                    required_set.add(key)

        if len(required_set) > 0:
            # We have complaints about what is missing. Return that.
            return required_set

        # We have a nice complete config. Return that.
        return config

    def create_base_chat_model(self, config: Dict[str, Any]) -> BaseLanguageModel:
        """
        Create a BaseLanguageModel from the fully-specified llm config.
        :param config: The fully specified llm config which is a product of
                    _create_full_llm_config() above.
        :return: A BaseLanguageModel (can be Chat or LLM)
                Can raise a ValueError if the config's class or model_name value is
                unknown to this method.
        """
        raise NotImplementedError

    def create_llm_resources(self, config: Dict[str, Any]) -> LangChainLlmResources:
        """
        Create a BaseLanguageModel from the fully-specified llm config either from standard LLM factory,
        user-defined LLM factory, or user-specified langchain model class.
        :param config: The fully specified llm config which is a product of
                    _create_full_llm_config() above.
        :return: A LangChainLlmResources instance containing
                a BaseLanguageModel (can be Chat or LLM) and all related resources
                necessary for managing the model run-time lifecycle.
                Can raise a ValueError if the config's class or model_name value is
                unknown to this method.
        """
        llm_resources: LangChainLlmResources = None

        # Loop through the loaded factories in order until we can find one
        # that can create the llm.
        found_exception: Exception = None
        llm_factory: LangChainLlmFactory = None
        for llm_factory in self.llm_factories:
            try:
                llm_resources = llm_factory.create_llm_resources(config)
                if llm_resources is not None and isinstance(llm_resources, LangChainLlmResources):
                    # We found what we were looking for
                    found_exception = None
                    break

                # Let the next model have a crack
                found_exception = None

            except NotImplementedError:
                # This allows for backwards compatibility with older LangChainLlmFactories
                llm: BaseLanguageModel = llm_factory.create_base_chat_model(config)
                if llm is not None:
                    if isinstance(llm, LangChainLlmResources):
                        # We found what we were looking for
                        found_exception = None
                        break
                    if isinstance(llm, BaseLanguageModel):
                        llm_resources = LangChainLlmResources(llm, None)
                        found_exception = None
                        break

                # Let the next model have a crack
                found_exception = None

            # Catch some common wrong or missing API key errors in a single place
            # with some verbose error messaging.
            except API_KEY_ERRORS as exception:
                # Will re-raise but with the right exception text it will
                # also provide some more helpful failure text.
                message: str = ApiKeyErrorCheck.check_for_api_key_exception(exception)
                if message is not None:
                    # Log the error with technical details so a sysadmin can correlate
                    # user-visible failures with the underlying provider error. INFO
                    # level (rather than ERROR) avoids alarming on the recovered-via-
                    # fallback path, while still being on by default in most deployments
                    # so the trail isn't lost.
                    #
                    # Scope of this check: only failures that fire at LLM *construction*
                    # time land here — i.e. the key is missing (None) or of the wrong
                    # data type (e.g. list/dict supplied via sly_data where a string is
                    # expected). A key that is structurally a string but rejected by the
                    # provider (wrong/expired/over-quota) doesn't fail construction; it
                    # fails at *runtime* on the first API call, and is handled by the
                    # analogous check in RunContextRunnable.invoke_agent_chain()
                    # (see run_context_runnable.py).
                    #
                    # The user-friendly `message` we raise is still reported to the user.
                    # The raised ValueError is collected by the fallback loop in
                    # LangChainRunContext.create_agent_with_fallbacks() and, if no
                    # fallback succeeds, aggregated into a final ValueError surfaced
                    # to the caller. Two cases to consider:
                    #
                    #   a) Env var missing / misconfigured — server-side fix.
                    #      The aggregated ValueError lands in server output (the operator
                    #      sees it), and this log line provides the technical detail to
                    #      diagnose it. The surfaced text looks like:
                    #
                    #          No fully-specified LLM found in llm_config or fallbacks.
                    #          The following errors occurred while constructing LLMs:
                    #
                    #          A value for the OPENAI_API_KEY environment variable must be
                    #          correctly set in the neuro-san server or run-time environment
                    #          in order to use this agent network.
                    #          ...
                    #
                    #   b) sly_data was supposed to supply the key — client-side fix.
                    #      The aggregated ValueError surfaces to the chat client so the
                    #      end user (or calling system) knows to provide the key in
                    #      sly_data.llm_config. The surfaced text looks like:
                    #
                    #          No fully-specified LLM found in llm_config or fallbacks.
                    #          LLM operation for this agent requires at least one of the
                    #          following set in sly_data.llm_config:
                    #          anthropic_api_key
                    #
                    raise ValueError(message) from exception
                found_exception = exception

            except ValueError as exception:
                # Let the next model have a crack
                found_exception = exception

        # Try resolving via "class" in config if llm factories failed
        #
        # Note: config["class"] is always set — if the user intended to use a default LLMs,
        # it will point to a known default like "openai" or "bedrock". In those cases,
        # we avoid re-resolving it here to prevent masking the original error with
        # a new one from create_base_chat_model_from_user_class.
        #
        # This fallback only applies when the user provides a non-default class path
        # and factory resolution failed.
        class_path: str = config.get("class")
        classes_value: List[str] = self.llm_infos.get("classes")
        default_llm_classes: Set[str] = set(classes_value)
        if (
            llm_resources is None
            and found_exception is not None
            and class_path not in default_llm_classes
        ):
            llm: BaseLanguageModel = self.create_base_chat_model_from_user_class(class_path, config)
            llm_resources = LangChainLlmResources(llm)
            found_exception = None

        if found_exception is not None:
            raise found_exception

        return llm_resources

    def create_base_chat_model_from_user_class(
            self,
            class_path: str,
            config: Dict[str, Any],
    ) -> BaseLanguageModel:
        """
        Create a BaseLanguageModel from the user-specified langchain model class.
        :param class_path: A string in the form of <package>.<module>.<Class>
        :param config: The fully specified llm config which is a product of
                    _create_full_llm_config() above.

        :return: A BaseLanguageModel
        """

        if not isinstance(class_path, str):
            raise ValueError("'class' in llm_config must be a string")

        # Resolve the 'class'
        llm_class: Type[BaseLanguageModel] = ResolverUtil.create_class(
            class_name=class_path,
            class_name_source="agent network hocon file",
            type_of_class=BaseLanguageModel
        )

        # Create a copy of the config, removing "class" and "verbose".
        # Note: "verbose" is valid for both Neuro SAN and LangChain chat models, but when specified by the user,
        # it should only apply to Neuro SAN (e.g. AgentExecutor) — not passed into the LLM constructor.
        user_config: Dict[str, Any] = {}
        llm_config_key: str = None
        llm_config_value: Any = None
        for llm_config_key, llm_config_value in config.items():
            if llm_config_key not in KEYS_TO_REMOVE_FOR_USER_CLASS:
                user_config[llm_config_key] = llm_config_value

        # Check for invalid args and throw error if found
        ArgumentValidator.check_invalid_args(llm_class, user_config)

        # Unpack user_config  into llm constructor
        return llm_class(**user_config)

    def get_max_prompt_tokens(self, config: Dict[str, Any]) -> Optional[int]:
        """
        :param config: A dictionary which describes which LLM to use.
        :return: The maximum number of tokens given the 'model_name' in the
                config dictionary, or None if the llm entry does not declare a
                fixed max_output_tokens (e.g. OpenRouter meta-routers where the
                underlying model is chosen per-request).
        """

        model_name: str = config.get("model_name")

        # Follow any alias to the entry that carries max_output_tokens.
        # Note that by the time create_full_llm_config() calls this, model_name has
        # already been replaced by the entry's own "use_model_name" (if any), so for
        # redirect entries like azure-gpt-4o this looks up the target entry, which is
        # where max_output_tokens actually lives.
        llm_entry: Dict[str, Any] = self._resolve_llm_entry(model_name)[0]

        entry_max_tokens: Optional[int] = llm_entry.get("max_output_tokens")
        prompt_token_fraction: Optional[float] = config.get("prompt_token_fraction")

        # Both factors must be concrete numbers for the multiplication to work —
        # entry_max_tokens is intentionally null in llm_info for models whose true
        # max_output_tokens is unknown until the underlying model is selected at
        # request time (e.g. openrouter/free, openrouter/auto). Without this guard,
        # int(None * fraction) raises TypeError, which has been observed to surface
        # as a hang upstream. Returning None lets callers fall back to the model's
        # own default.
        use_max_tokens: Optional[int] = None
        if entry_max_tokens is not None and prompt_token_fraction is not None:
            use_max_tokens = int(entry_max_tokens * prompt_token_fraction)

        # Allow the actual value for max_tokens to come from the config, if there
        max_prompt_tokens: Optional[int] = config.get("max_tokens", use_max_tokens)
        if max_prompt_tokens is None:
            max_prompt_tokens = use_max_tokens

        return max_prompt_tokens

    # pylint: disable=too-many-branches,too-many-locals,too-many-statements
    def create_llm_with_fallbacks(self, config: Dict[str, Any],
                                  sly_data: Dict[str, Any] = None,
                                  num_fallbacks: int = None,
                                  randomize_peers: bool = False) -> LangChainLlmResources | Dict[str, Any]:
        """
        :param config: A dictionary which describes which LLM to use, perhaps with fallbacks specified.
        :param sly_data: A user-provided dictionary of private data,
                from which we might extract API keys to use for user billing.
                Can be None indicating no API keys are provided at all and the system defaults will be used.
        :param num_fallbacks: The number of fallbacks to try. Default value of None implies all.
        :param randomize_peers: If True, randomize the order of the fallbacks within the group.
        :return: A LangChainLlmResources instance or if no valid llm was found or
                a dictionary whose keys are error types and whose values are lists of error strings
                for that type.  If there were valid and useable fallbacks specified,
                those will be set up as fallbacks for the model on the LlmResources object.
        """
        provider_tools: Optional[List[Dict[str, Any]]] = config.get("provider_tools")

        # Prepare a list of fallbacks.  By default, the llm_config itself is a single-entry fallback list.
        fallbacks: List[Dict[str, Any]] = [config]
        fallbacks = config.get("fallbacks", fallbacks)

        # Initialize a list of chain fallbacks. This may or may not get filled.
        main_llm_resources: LangChainLlmResources = None
        fallback_llm_resources: List[LangChainLlmResources] = []

        # Different kinds of errors we might encounter and report separately
        required_sly_data: Set[str] = set()
        api_key_errors: Set[str] = set()
        construction_errors: Set[str] = set()

        # Trim the list of fallbacks.
        if num_fallbacks is not None:
            if num_fallbacks < 0:
                # Take it from the end
                fallbacks = fallbacks[num_fallbacks:]
            else:
                # Take it from the beginning
                fallbacks = fallbacks[:num_fallbacks]

        # Go through the list of fallbacks in the config.
        # An entry is normally a config dictionary, but a nested list is a peer group.
        fallback: Any = None
        for fallback in fallbacks:

            # Create a model we might use.
            # If construction fails (e.g. missing API key in env), record the error and
            # try the next fallback rather than aborting the whole loop.
            one_llm_resources: LangChainLlmResources | Set[str] | Dict[str, Any] = None

            if isinstance(fallback, list):
                # Fallback lists grouped by further lists of fallbacks are peers for randomization.
                sub_config: Dict[str, Any] = {
                    "fallbacks": fallback,
                    "provider_tools": provider_tools,
                }
                one_llm_resources = self.create_llm_with_fallbacks(sub_config, sly_data=sly_data, num_fallbacks=None,
                                                                   randomize_peers=True)
                if isinstance(one_llm_resources, dict):
                    # It was a bust. Update our own error sets
                    api_key_errors.update(one_llm_resources.get("api_key_errors", []))
                    construction_errors.update(one_llm_resources.get("construction_errors", []))
                    required_sly_data.update(one_llm_resources.get("required_sly_data_errors", []))
                    continue

            try:
                if one_llm_resources is None:
                    one_llm_resources = self.create_llm(fallback, sly_data)
            except ValueError as exception:
                # API Key errors get thrown as ValueErrors but have their
                # "from" __cause__ set as the original exception.
                # Examine that so we can report those separately.
                if exception.__cause__ is not None:
                    cause: Exception = exception.__cause__
                    message: str = ApiKeyErrorCheck.check_for_api_key_exception(cause)
                    if message is not None:
                        # Make sure the message is fit for public consumption with no
                        # explicit secrets in the text.
                        message = ApiKeyErrorCheck.get_safe_log_message(exception)
                        api_key_errors.add(message)
                        continue

                construction_errors.add(str(exception))
                continue

            if one_llm_resources is None:
                # Nothing to use or report.
                # Skip for now, a fallback might still be fulfilled.
                continue

            if isinstance(one_llm_resources, set):
                # Report later on which required llm_config are missing
                # Skip for now, a fallback might still be fulfilled.
                required_sly_data.update(one_llm_resources)
                continue

            if main_llm_resources is None:
                # The first fully-specified llm is the one we want to be our main guy.
                main_llm_resources = one_llm_resources
            else:
                # Anything later than the first guy is considered a fallback. Add it to the list.
                fallback_llm_resources.append(one_llm_resources)

        if main_llm_resources is None:
            # Return all errors
            return {
                "api_key_errors": sorted(api_key_errors),
                "construction_errors": sorted(construction_errors),
                "required_sly_data_errors": sorted(required_sly_data),
            }

        if len(fallback_llm_resources) > 0:

            if provider_tools:
                main_policy_type = type(main_llm_resources.get_llm_policy())
                fallback_policy_types: Set[type] = set()
                resources: LangChainLlmResources = None
                for resources in fallback_llm_resources:
                    fallback_policy_types.add(type(resources.get_llm_policy()))

                # User-defined dotted classes do not attach a policy, so different
                # custom classes both appear as NoneType and cannot be distinguished here.
                if fallback_policy_types != {main_policy_type}:
                    policy_types: Set[type] = {main_policy_type}
                    policy_types.update(fallback_policy_types)
                    policy_names: List[str] = []
                    policy_type: type = None
                    for policy_type in policy_types:
                        policy_names.append(policy_type.__name__)
                    policy_names.sort()
                    raise ValueError(
                        "provider_tools requires all fallback LLMs to use the same provider; "
                        f"found {', '.join(policy_names)}"
                    )

            if randomize_peers:
                # Prepare a list of all LlmResources to be randomized, including the main one
                randomized: List[LangChainLlmResources] = shallow_copy(fallback_llm_resources)
                randomized.append(main_llm_resources)

                # Randomize the list in place
                shuffle(randomized)

                # Take one as the main one. Doesn't matter which.
                main_llm_resources = randomized.pop()

                # Take the rest as fallbacks in the order that remains
                fallback_llm_resources = randomized

            # Set up fallbacks.
            # See https://python.langchain.com/docs/how_to/tools_error/#tryexcept-tool-call
            main_llm_resources.add_fallback_resources(fallback_llm_resources)

        return main_llm_resources

    def get_llm_infos(self) -> Dict[str, Any]:
        """
        :return: A dictionary mapping llm names to their descriptions.
        """
        return self.llm_infos
