
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Any
from typing import Dict
from typing import Type

from contextlib import suppress

from langchain_core.language_models.base import BaseLanguageModel

from leaf_common.config.config_util import ConfigUtil

from neuro_san.internals.run_context.langchain.llms.closeable_client import CloseableClient
from neuro_san.internals.run_context.langchain.llms.llm_policy import LlmPolicy


class GeminiLlmPolicy(LlmPolicy):
    """
    LlmPolicy implementation for Gemini.
    """

    def create_llm(self, config: Dict[str, Any], model_name: str, client: Any) -> BaseLanguageModel:
        """
        Create a BaseLanguageModel instance from the fully-specified llm config
        for the llm class that the implementation supports.  Chat models are usually
        per-provider, where the specific model itself is an argument to its constructor.

        :param config: The fully specified llm config
        :param model_name: The name of the model
        :param client: The web client to use (if any)
        :return: A BaseLanguageModel (can be Chat or LLM)
        """
        # Use lazy loading to prevent installing the world
        # pylint: disable=invalid-name
        ChatGoogleGenerativeAI: Type[BaseLanguageModel] = self.resolver.resolve_class_in_module(
            "ChatGoogleGenerativeAI",
            module_name="langchain_google_genai.chat_models",
            install_if_missing="langchain-google-genai")

        llm: BaseLanguageModel = ChatGoogleGenerativeAI(
            model=model_name,
            google_api_key=self.get_value_or_env(config, "google_api_key",
                                                 "GOOGLE_API_KEY"),
            max_retries=config.get("max_retries"),
            max_tokens=config.get("max_tokens"),  # This is always for output
            n=config.get("n"),
            temperature=config.get("temperature"),
            timeout=config.get("timeout"),
            top_k=config.get("top_k"),
            top_p=config.get("top_p"),
            thinking_level=config.get("thinking_level"),
            thinking_budget=config.get("thinking_budget"),

            # When true, Gemini returns its thought summaries as thinking blocks in the
            # message content, so the reasoning behind a reply becomes visible to the caller.
            # A summary is not guaranteed on every reply: the model may reason without
            # emitting one.  Thought signatures (which carry the model's reasoning across
            # tool calls within a single request) round-trip regardless of this flag, so
            # leaving it unset never affects tool calling.  We use config.get() rather than
            # get_bool() so that an absent key stays None and langchain omits the field from
            # the thinking config instead of sending an explicit false.
            # See https://docs.langchain.com/oss/python/integrations/chat/google_generative_ai
            # and https://ai.google.dev/gemini-api/docs/thinking
            include_thoughts=config.get("include_thoughts"),

            # Streaming is configurable via the "streaming" key in llm_config; defaults
            # to False so existing agents keep their long-standing non-streaming behavior.
            # We pass streaming explicitly (rather than relying on LangChain's default) so
            # that langchain_core._should_stream() picks up the configured value even when
            # a streaming-aware callback handler is attached to the run manager.
            streaming=ConfigUtil.get_bool(config, "streaming"),

            # If omitted, this defaults to the global verbose value,
            # accessible via langchain_core.globals.get_verbose():
            # https://github.com/langchain-ai/langchain/blob/master/libs/core/langchain_core/globals.py#L53
            #
            # However, accessing the global verbose value during concurrent initialization
            # can trigger the following warning:
            #
            # UserWarning: Importing verbose from langchain root module is no longer supported.
            # Please use langchain.globals.set_verbose() / langchain.globals.get_verbose() instead.
            # old_verbose = langchain.verbose
            #
            # To prevent this, we explicitly set verbose=False here (which matches the default
            # global verbose value) so that the warning is never triggered.
            verbose=False,
        )
        # Cosmetic only: silences google-genai's misleading "AFC is enabled" log banner.
        # Behavior is identical with or without this.
        return self._disable_afc(llm)

    def _disable_afc(self, llm: BaseLanguageModel) -> Any:
        """
        Explicitly disable the google-genai SDK's Automatic Function Calling (AFC)
        on the given llm, if the environment allows it.

        AFC is a client-side convenience feature of the google-genai SDK that can
        only auto-execute tools passed to the SDK as Python callables.  LangChain
        binds tools as function declarations (schemas), so AFC can never execute
        anything here -- function calling is governed entirely by neuro-san's own
        agent loop.  However, when AFC is not explicitly disabled, the SDK logs a
        misleading "AFC is enabled with max remote calls: 10." INFO banner on
        LLM calls made with no tools bound (e.g. by agents with no down-chain
        tools).  Disabling AFC is behaviorally a no-op that silences that banner.
        See https://github.com/cognizant-ai-lab/neuro-san/issues/1096

        ChatGoogleGenerativeAI has no constructor argument for this -- the setting
        is only honored as a per-request kwarg -- hence bind().

        Note that requests with tools bound do not inherit bind() kwargs, so they
        do not carry the explicit disable.  They are banner-free regardless:
        google-genai >= 1.48 skips its AFC path entirely for declaration-style
        tools, and langchain-google-genai >= 4.1.2 (our floor) requires
        google-genai >= 1.56.

        :param llm: The ChatGoogleGenerativeAI instance to disable AFC on.
        :return: llm.bind(...) with AFC disabled, which behaves like the original
                llm.  The original llm is returned unchanged when the environment
                cannot support the bind:
                * Without the google-genai SDK (langchain-google-genai < 4.0 builds
                  on google-ai-generativelanguage), there is no AFC to disable.
                * On langchain-core < 1.4, bind() returns a generic RunnableBinding
                  with no bind_tools() method, which would break agent creation for
                  agents with tools.  There the cosmetic banner is left alone.
        """
        # Use lazy loading to prevent installing the world.
        # google-genai comes with langchain-google-genai >= 4.0, so intentionally
        # no install_if_missing here: an older stack has no AFC to disable.
        # pylint: disable=invalid-name
        AutomaticFunctionCallingConfig: Type[Any] = self.resolver.resolve_class_in_module(
            "AutomaticFunctionCallingConfig",
            module_name="google.genai.types",
            raise_if_not_found=False)
        if AutomaticFunctionCallingConfig is None:
            # No google-genai SDK, so no AFC (and no banner) to worry about.
            return llm

        # AFC can only be disabled per-request, so bind the setting onto every call.
        bound: Any = llm.bind(automatic_function_calling=AutomaticFunctionCallingConfig(disable=True))
        if not hasattr(bound, "bind_tools"):
            # langchain-core < 1.4: bind() gives a generic RunnableBinding whose missing
            # bind_tools() would break agent creation.  Keep the harmless banner instead.
            return llm

        return bound

    async def delete_resources(self):
        """
        Release the run-time resources used by the model
        """
        if self.llm is None:
            return

        # Do the necessary reach-ins to successfully shut down the web client
        # langchain-google-genai is built on google-genai:
        # when ChatGoogleGenerativeAI is instantiated, it creates google.genai.Client
        # via the validate_environment method
        # (https://github.com/langchain-ai/langchain-google/blob/main/libs/genai/langchain_google_genai/
        # chat_models.py#L2306).
        #
        # The google.genai.Client internally creates both sync and async client instances,
        # so both Client and AsyncClient (accessible via client.aio) are instantiated
        # at this time.
        #
        # The async_client @property
        # (https://github.com/langchain-ai/langchain-google/blob/main/libs/genai/langchain_google_genai/
        # chat_models.py#L2476)
        # simply returns self.client.aio - it doesn't create a new client, just provides
        # convenient access to the already-instantiated AsyncClient.
        #
        # Therefore, both clients exist immediately upon ChatGoogleGenerativeAI instantiation
        # and both should be closed during cleanup.
        #
        # References:
        # https://github.com/langchain-ai/langchain-google/releases/tag/libs%2Fgenai%2Fv4.0.0
        # https://github.com/googleapis/python-genai/blob/main/google/genai/client.py
        # https://reference.langchain.com/python/integrations/langchain_google_genai/ChatGoogleGenerativeAI/
        # #langchain_google_genai.ChatGoogleGenerativeAI.async_client

        # The llm may be a bind() wrapper around the actual chat model
        # (see _disable_afc), in which case the clients live on its "bound" attribute.
        base_llm: Any = getattr(self.llm, "bound", self.llm)

        # Close sync client
        if base_llm.client is not None:
            with suppress(Exception):
                closeable_client: CloseableClient = base_llm.client
                closeable_client.close()

        # Close async client
        if base_llm.async_client is not None:
            with suppress(Exception):
                closeable_client: CloseableClient = base_llm.async_client
                await closeable_client.aclose()

        # Let's not do this again, shall we?
        self.llm = None
