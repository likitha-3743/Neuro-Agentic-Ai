
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT

from typing import Dict
from typing import List
from typing import Set

from logging import getLogger
from logging import Logger
from threading import Lock

from neuro_san.internals.graph.registry.agent_network import AgentNetwork
from neuro_san.internals.interfaces.agent_network_provider import AgentNetworkProvider
from neuro_san.internals.interfaces.agent_state_listener import AgentStateListener
from neuro_san.internals.interfaces.agent_storage_source import AgentStorageSource
from neuro_san.internals.network_providers.single_agent_network_provider import SingleAgentNetworkProvider


class AgentNetworkStorage(AgentStorageSource):
    """
    Service-wide storage for AgentNetworkProviders containing
    a table of currently active AgentNetworks for each agent registered to the service.
    Note: a mapping from an agent to its AgentNetwork is dynamic,
          as it is possible to change agents definitions at service run-time.
    """

    def __init__(self):
        self.agents_table: Dict[str, AgentNetwork] = {}
        self.logger: Logger = getLogger(self.__class__.__name__)
        self.lock: Lock = Lock()
        self.listeners: List[AgentStateListener] = []

    def add_listener(self, listener: AgentStateListener):
        """
        Add a state listener to be notified when status of service agents changes.
        """
        self.listeners.append(listener)

    def remove_listener(self, listener: AgentStateListener):
        """
        Remove a state listener from registered set.
        """
        if listener in self.listeners:
            self.listeners.remove(listener)

    def add_agent_network(self, agent_name: str, agent_network: AgentNetwork):
        """
        This method is a single point of entry in the service
        where we register a new agent name -> AgentNetwork pair in the service scope
        or notify the service that for existing agent its AgentNetwork has been modified.
        """
        is_new: bool = False
        with self.lock:
            test_agent_network: AgentNetwork = self.agents_table.get(agent_name)
            is_new = test_agent_network is None
            self.agents_table[agent_name] = agent_network

        agent_size_in_bytes: int = agent_network.get_size_in_bytes()

        # Notify listeners about this state change:
        # do it outside of internal lock
        listener: AgentStateListener = None
        for listener in self.listeners:
            if is_new:
                listener.agent_added(agent_name, self)
                self.logger.info("ADDED network for agent %s (%d bytes): %d",
                                 agent_name, agent_size_in_bytes, id(agent_network))
            else:
                listener.agent_modified(agent_name, self)
                self.logger.info("REPLACED network for agent %s (%d bytes): %d",
                                 agent_name, agent_size_in_bytes, id(agent_network))

    def setup_agent_networks(self, agent_networks: Dict[str, AgentNetwork]):
        """
        Replace agents networks with a new collection.
        Previous state could be empty.
        """
        current_agents: Set[str] = set(self.agents_table.keys())
        new_agents: Set[str] = set(agent_networks.keys())
        # Remove agents which are not in the new collection:
        agents_to_remove: Set[str] = current_agents - new_agents
        agent_name: str = None
        for agent_name in agents_to_remove:
            self.remove_agent_network(agent_name)
        # Now add (or possibly replace) agents from new collection:
        for agent_name in new_agents:
            self.add_agent_network(agent_name, agent_networks[agent_name])

    def remove_agent_network(self, agent_name: str):
        """
        Remove agent name and its AgentNetwork from service scope,
        so that agent becomes unavailable on our server.
        """
        agent_network: AgentNetwork = None
        with self.lock:
            agent_network = self.agents_table.get(agent_name, None)
            self.agents_table.pop(agent_name, None)

        # Notify listeners about this state change:
        # do it outside of internal lock
        listener: AgentStateListener = None
        for listener in self.listeners:
            listener.agent_removed(agent_name, self)
        # We can log id(None) if necessary - that's a legal value
        self.logger.info("REMOVED network for agent %s : %d", agent_name, id(agent_network))

    def get_agent_network_provider(self, agent_name: str) -> AgentNetworkProvider:
        """
        Get AgentNetworkProvider for a specific agent
        :param agent_name: name of an agent
        """
        return SingleAgentNetworkProvider(agent_name, self.agents_table)

    def get_agent_names(self) -> List[str]:
        """
        Return static list of agent names.
        """
        with self.lock:
            # Create static snapshot of agents names collection
            return list(self.agents_table.keys())
