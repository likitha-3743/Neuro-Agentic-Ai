
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
from __future__ import annotations

from typing import Any
from typing import Dict

from abc import abstractmethod
from threading import Event

from leaf_common.asyncio.asyncio_executor import AsyncioExecutor
from leaf_common.utils.interface import interface

from neuro_san.interfaces.reservationist import Reservationist
from neuro_san.internals.chat.async_collating_queue import AsyncCollatingQueue
from neuro_san.internals.interfaces.async_agent_session_factory import AsyncAgentSessionFactory
from neuro_san.internals.interfaces.context_type_toolbox_factory import ContextTypeToolboxFactory
from neuro_san.internals.interfaces.context_type_llm_factory import ContextTypeLlmFactory
from neuro_san.internals.interfaces.lingering_resource import LingeringResource
from neuro_san.internals.journals.journal import Journal
from neuro_san.internals.journals.origination import Origination


@interface
class InvocationContext(LingeringResource):
    """
    Top-level interface for encapsulating specific policy classes that pertain to
    a single invocation of an AgentSession or AsyncAgentSession, whether by way of a
    service call or library call.

    An InvocationContext will last for the duration of the work initiated by Session/request,
    which could outlive the Session/request itself, depending on just how its invocation is
    configured.
    """

    @abstractmethod
    def start(self):
        """
        Starts the active components of this invocation context.
        Do this separately from constructor for more control.
        """
        raise NotImplementedError

    @abstractmethod
    def get_effective_invocation(self) -> str:
        """
        :return: The effective invocation of the session
        """
        raise NotImplementedError

    @abstractmethod
    def get_async_session_factory(self) -> AsyncAgentSessionFactory:
        """
        :return: The AsyncAgentSessionFactory associated with the invocation
        """
        raise NotImplementedError

    @abstractmethod
    def get_asyncio_executor(self) -> AsyncioExecutor:
        """
        :return: The AsyncioExecutor associated with the invocation
        """
        raise NotImplementedError

    @abstractmethod
    def get_origination(self) -> Origination:
        """
        :return: The Origination instance carrying state about tool instantation
                during the course of the AgentSession.
        """
        raise NotImplementedError

    @abstractmethod
    def get_journal(self) -> Journal:
        """
        :return: The Journal instance that allows message reporting
                during the course of the AgentSession.
        """
        raise NotImplementedError

    @abstractmethod
    def get_queue(self) -> AsyncCollatingQueue:
        """
        :return: The AsyncCollatingQueue instance via which messages are streamed to the
                QueueFilter mechanics
        """
        raise NotImplementedError

    @abstractmethod
    def get_metadata(self) -> Dict[str, str]:
        """
        :return: The metadata to pass along with any request
        """
        raise NotImplementedError

    @abstractmethod
    async def close_of_request(self, parent_resource: LingeringResource = None):
        """
        Release resources owned by this context when the request is complete.
        This can happen earlier than when the work is complete.

        :param parent_resource: The parent resource, if any
        """
        raise NotImplementedError

    @abstractmethod
    async def close_of_work(self, parent_resource: LingeringResource = None):
        """
        Release resources owned by this context when the work is all done.
        This can happen later than when the request is complete.

        :param parent_resource: The parent resource, if any
        """
        raise NotImplementedError

    @abstractmethod
    def get_request_reporting(self) -> Dict[str, Any]:
        """
        :return: The request reporting dictionary
        """
        raise NotImplementedError

    @abstractmethod
    def is_cloned(self) -> bool:
        """
        :return: True if this instance is a clone of a request's original
                InvocationContext, created to invoke an external agent network
                on the same server via a direct session.
                False for the original InvocationContext of a request.
        """
        raise NotImplementedError

    @abstractmethod
    def get_llm_factory(self) -> ContextTypeLlmFactory:
        """
        :return: The ContextTypeLlmFactory instance for the session
        """
        raise NotImplementedError

    @abstractmethod
    def get_toolbox_factory(self) -> ContextTypeToolboxFactory:
        """
        :return: The ContextTypeToolboxFactory instance for the session
        """
        raise NotImplementedError

    @abstractmethod
    def get_reservationist(self) -> Reservationist:
        """
        :return: The Reservationist instance for the session
        """
        raise NotImplementedError

    @abstractmethod
    def get_port(self) -> int:
        """
        :return: The port on which the server was started
        """
        raise NotImplementedError

    @abstractmethod
    def get_work_done_event(self) -> Event:
        """
        :return: The Event (synchronous) that will be set when work is done for this event
        """
        raise NotImplementedError

    @abstractmethod
    def add_resource(self, resource: LingeringResource):
        """
        :param resource: The resource to add
        """
        raise NotImplementedError

    @abstractmethod
    def safe_shallow_copy(self, invocation: str = None) -> InvocationContext:
        """
        Makes a safe shallow copy of the invocation context.
        Generally used with direct sessions.

        :param invocation: String describing how the agent wants to be invoked.
                            Can be: "chatbot" - implies waiting for an answer.
                                    "event" - implies no answer needed
                                    None - implies chatbot
        :return: A copy of the invocation context
        """
        raise NotImplementedError

    @abstractmethod
    def get_agent_name(self) -> str:
        """
        :return: The agent name for the session
        """
        raise NotImplementedError
